const state = {
  page: null,
  telemetry: null,
  device: null,
  pages: [],
  displayText: "",
  log: [],
  pageJsonDraft: "",
  currentPageId: null,
  discovery: [],
  selectedBonjourService: null
};

function logLine(msg) {
  const line = `[${new Date().toLocaleTimeString()}] ${msg}`;
  state.log.unshift(line);
  state.log = state.log.slice(0, 10);
  const el = document.getElementById("event-log");
  if (el) el.textContent = state.log.join("\n");
}

function renderJson(el, value) {
  if (el) el.textContent = JSON.stringify(value, null, 2);
}

function getSavedServerUrl() {
  try {
    return localStorage.getItem("demo.serverUrl") || "";
  } catch {
    return "";
  }
}

function setSavedServerUrl(url) {
  try {
    localStorage.setItem("demo.serverUrl", url);
  } catch {}
}

function serviceUrl(service) {
  const host = service?.addresses?.[0] || service?.host || "";
  return host ? `http://${host}:${service.port}` : "";
}

function isSameService(service, other) {
  if (!service || !other) return false;
  return (
    service.name === other.name ||
    service.host === other.host ||
    (service.addresses || []).includes(other.host) ||
    (other.addresses || []).includes(service.host)
  );
}

function renderServerList(services) {
  const list = document.getElementById("server-list");
  if (!list) return;
  list.innerHTML = "";
  if (!services || services.length === 0) {
    list.textContent = "No services found.";
    return;
  }

  services.forEach((service) => {
    const item = document.createElement("button");
    item.type = "button";
    const isSelected = Boolean(state.selectedBonjourService && isSameService(service, state.selectedBonjourService));
    item.className = `server-item${isSelected ? " is-selected" : ""}`;
    const host = service.addresses?.[0] || service.host || "";
    const url = serviceUrl(service);
    item.innerHTML = `
      <span class="server-item-name">${service.name || "unnamed"}</span>
      <span class="server-item-meta">${host || service.host || "?"}:${service.port || "?"}</span>
    `;
    item.addEventListener("click", () => {
      if (!url) return;
      const select = document.getElementById("server-choice");
      if (select) {
        const index = state.discovery.findIndex((candidate) => isSameService(candidate, service));
        if (index >= 0) select.value = String(index);
      }
      selectBonjourService(service).catch((err) => logLine(`server select failed: ${err.message}`));
    });
    list.appendChild(item);
  });
}

function renderServerChoices(services) {
  const select = document.getElementById("server-choice");
  if (!select) return;
  select.innerHTML = "";

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = services && services.length > 0 ? "Choose a Bonjour server" : "No Bonjour servers";
  select.appendChild(placeholder);

  (services || []).forEach((service, index) => {
    const option = document.createElement("option");
    option.value = String(index);
    option.textContent = `${service.name || "unnamed"} — ${serviceUrl(service) || service.host || "?"}:${service.port || "?"}`;
    if (state.selectedBonjourService && isSameService(service, state.selectedBonjourService)) {
      option.selected = true;
    }
    select.appendChild(option);
  });
}

async function selectBonjourService(service) {
  const host = service?.addresses?.[0] || service?.host || "";
  const url = host ? `http://${host}:${service.port}` : "";
  if (!url) return;
  const input = document.getElementById("server-url");
  if (input) input.value = url;
  setSavedServerUrl(url);
  const payload = await api("/api/server-target", {
    method: "POST",
    body: JSON.stringify({
      service: {
        name: service.name || "",
        host,
        port: service.port || 0,
        url
      }
    })
  });
  state.selectedBonjourService = payload.selectedBonjourService || null;
  renderServerList(state.discovery);
  renderServerChoices(state.discovery);
  logLine(`server selected: ${url}`);
}

function syncPageJsonEditor(page) {
  const editor = document.getElementById("page-json");
  if (!editor) return;
  if (document.activeElement === editor || editor.dataset.editing === "true") return;
  const pageId = page?.id || "";
  const samePage = editor.dataset.pageId === pageId;
  if (samePage && editor.dataset.userEdited === "true") return;
  const nextValue = JSON.stringify(page || {}, null, 2);
  editor.value = nextValue;
  editor.dataset.dirty = "false";
  editor.dataset.userEdited = "false";
  editor.dataset.pageId = pageId;
  state.pageJsonDraft = nextValue;
}

function formatControlValue(control) {
  if (control.type === "toggle") return control.value ? "ON" : "OFF";
  if (control.type === "button") return String(control.value ?? control.label ?? "press");
  if (control.type === "meter" && typeof control.value === "number") {
    if (control.unit === "C") return `${control.value.toFixed(1)} C`;
    if (control.unit === "dBm") return `${control.value.toFixed(0)} dBm`;
    if (control.value >= 0 && control.value <= 1) return `${Math.round(control.value * 100)}%`;
    return `${control.value}`;
  }
  return String(control.value);
}

function clampPercent(value) {
  if (Number.isNaN(value)) return 0;
  return Math.max(0, Math.min(100, value));
}

function getDisplaySize(control) {
  const size = Number(control?.displaySize || 1);
  return Number.isFinite(size) && size > 0 ? size : 1;
}

function scaleFont(baseRem, control) {
  const size = getDisplaySize(control);
  const factor = size <= 1 ? 1 : size === 2 ? 1.48 : 1.48 + (size - 2) * 0.2;
  return `${(baseRem * factor).toFixed(2)}rem`;
}

function createCard(control) {
  const card = document.createElement("div");
  card.className = "screen-card";
  const displaySize = getDisplaySize(control);

  if (control.id === "chars") {
    card.classList.add("screen-card-calibration");
    const value = document.createElement("div");
    value.className = "screen-card-value";
    value.textContent = String(control.value ?? "").replace(/\s+/g, "");
    value.style.fontSize = scaleFont(0.84, control);
    card.appendChild(value);
    return card;
  }

  const label = document.createElement("div");
  label.className = "screen-card-label";
  label.textContent = control.label || control.id || "item";
  label.style.fontSize = "0.92rem";
  card.appendChild(label);

  if (control.type === "meter" && typeof control.value === "number") {
    card.classList.add("screen-card-meter");
    const value = document.createElement("div");
    value.className = "screen-meter-value";
    value.textContent = formatControlValue(control);
    value.style.fontSize = scaleFont(0.84, control);
    card.appendChild(value);

    if (control.unit) {
      const unit = document.createElement("div");
      unit.className = "screen-badge";
      unit.textContent = control.unit;
      unit.style.fontSize = scaleFont(0.68, control);
      card.appendChild(unit);
    }
    return card;
  }

  if (control.type === "slider" && typeof control.value === "number") {
    card.classList.add("screen-card-slider");
    const bar = document.createElement("div");
    bar.className = "screen-bar screen-bar-gradient";
    const fill = document.createElement("div");
    fill.className = "screen-bar-fill";
    fill.style.width = `${clampPercent(control.value * 100)}%`;
    bar.appendChild(fill);
    card.appendChild(bar);
  } else if (control.type === "toggle") {
    const pill = document.createElement("div");
    pill.className = `screen-pill ${control.value ? "is-on" : "is-off"}`;
    pill.textContent = control.value ? "ON" : "OFF";
    pill.style.fontSize = scaleFont(0.68, control);
    card.appendChild(pill);
  } else if (control.type === "selector") {
    card.classList.add("screen-card-selector");
    const value = document.createElement("div");
    value.className = "screen-selector-value";
    value.textContent = String(control.value ?? "");
    value.style.fontSize = scaleFont(0.68, control);
    card.appendChild(value);
  } else if (control.type === "button") {
    card.classList.add("screen-card-button", `variant-${String(control.variant || "primary").toLowerCase()}`);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "screen-control-button";
    button.dataset.controlId = control.id || "";
    button.dataset.variant = String(control.variant || "primary").toLowerCase();
    button.textContent = control.label || control.value || control.id || "button";
    button.style.fontSize = scaleFont(0.72, control);
    button.addEventListener("click", async () => {
      try {
        await api("/api/control", {
          method: "POST",
          body: JSON.stringify({
            type: "button",
            controlId: control.id,
            label: control.label || control.id || "button",
            value: control.value ?? control.label ?? control.id,
            variant: control.variant || "primary",
            webhook: control.webhook || ""
          })
        });
        logLine(`button pressed: ${control.id}`);
        await refresh();
      } catch (err) {
        logLine(`button failed: ${err.message}`);
      }
    });
    card.appendChild(button);
  } else {
    const value = document.createElement("div");
    value.className = "screen-card-value";
    value.textContent = formatControlValue(control);
    value.style.fontSize = scaleFont(0.84, control);
    card.appendChild(value);
  }

  return card;
}

function renderScreen(page, text) {
  const wrap = document.getElementById("screen-content");
  wrap.innerHTML = "";

  const title = document.createElement("div");
  title.className = "screen-title";
  title.textContent = page?.title || "Module";
  wrap.appendChild(title);

  const cardsWrap = document.createElement("div");
  cardsWrap.className = "screen-cards";
  wrap.appendChild(cardsWrap);

  const controls = Array.isArray(page?.controls) ? page.controls : [];
  if (controls.length > 0) {
    controls.slice(0, 4).forEach((control) => {
      cardsWrap.appendChild(createCard(control));
    });
    return;
  }

  String(text || "")
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 4)
    .forEach((line) => {
      const card = document.createElement("div");
      card.className = "screen-card";
      const label = document.createElement("div");
      label.className = "screen-card-label";
      label.textContent = line;
      card.appendChild(label);
      cardsWrap.appendChild(card);
    });
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options
  });
  return res.json();
}

async function discoverServers() {
  const list = document.getElementById("server-list");
  if (list) list.textContent = "Searching Bonjour services...";
  try {
    const payload = await api("/api/discovery?type=http&timeoutMs=1500");
    state.discovery = payload.services || [];
    renderServerList(state.discovery);
    renderServerChoices(state.discovery);
    logLine(`discovered ${state.discovery.length} server(s)`);
  } catch (err) {
    if (list) list.textContent = `Discovery failed: ${err.message}`;
    logLine(`discovery failed: ${err.message}`);
  }
}

async function refresh() {
  const [payload, displayText] = await Promise.all([
    api("/api/state"),
    fetch("/api/display.txt").then((res) => res.text())
  ]);
  state.page = payload.page;
  state.currentPageId = payload.page?.id || null;
  state.telemetry = payload.telemetry;
  state.device = payload.device;
  state.pages = payload.pages || [];
  state.selectedBonjourService = payload.page?.selectedBonjourService || null;
  state.displayText = displayText;
  renderServerChoices(state.discovery);

  const status = document.getElementById("connection-status");
  const connected = Boolean(payload.device);
  status.textContent = connected ? "connected" : "waiting";
  status.classList.toggle("is-connected", connected);
  status.classList.toggle("is-waiting", !connected);
  if (connected && payload.device.ip) {
    status.title = `Device IP: ${payload.device.ip}`;
  } else {
    status.title = "Waiting for hello";
  }

  renderScreen(payload.page, displayText);
  syncPageJsonEditor(payload.page);
  renderJson(document.getElementById("device-json"), payload.device || { status: "waiting for hello" });
  renderJson(document.getElementById("telemetry-json"), payload.telemetry || { status: "waiting for telemetry" });
}

async function applyPageJson() {
  const editor = document.getElementById("page-json");
  if (!editor) return;
  let parsed;
  try {
    parsed = JSON.parse(editor.value);
  } catch (err) {
    logLine(`page JSON invalid: ${err.message}`);
    return;
  }

  const payload = await api("/api/page", {
    method: "POST",
    body: JSON.stringify({ page: parsed })
  });
  editor.dataset.dirty = "false";
  editor.dataset.userEdited = "false";
  editor.dataset.pageId = payload.page?.id || editor.dataset.pageId || "";
  state.page = payload.page;
  logLine(`page JSON applied: ${payload.page.title || "Module"}`);
  await refresh();
}

function resetPageJson() {
  const editor = document.getElementById("page-json");
  if (!editor) return;
  editor.value = JSON.stringify(state.page || {}, null, 2);
  editor.dataset.dirty = "false";
  editor.dataset.userEdited = "false";
  editor.dataset.pageId = state.page?.id || "";
  state.pageJsonDraft = editor.value;
  logLine("page JSON reset");
}

async function swipe(dir) {
  const payload = await api("/api/swipe", {
    method: "POST",
    body: JSON.stringify({ dir })
  });
  state.page = payload.page;
  logLine(`swipe ${dir} -> ${payload.page.title}`);
  await refresh();
}

function boot() {
  document.getElementById("prev-page").addEventListener("click", () => swipe("prev"));
  document.getElementById("next-page").addEventListener("click", () => swipe("next"));
  const serverInput = document.getElementById("server-url");
  if (serverInput) {
    serverInput.value = getSavedServerUrl() || state.selectedBonjourService?.url || "";
  }
  document.getElementById("discover-servers").addEventListener("click", () => {
    discoverServers().catch((err) => logLine(`discovery failed: ${err.message}`));
  });
  document.getElementById("use-selected-server").addEventListener("click", () => {
    const select = document.getElementById("server-choice");
    const index = select ? Number(select.value) : -1;
    const service = Number.isInteger(index) && index >= 0 ? state.discovery[index] : null;
    if (!service) {
      logLine("no Bonjour server selected");
      return;
    }
    selectBonjourService(service).catch((err) => logLine(`server select failed: ${err.message}`));
  });
  document.getElementById("save-server").addEventListener("click", () => {
    const input = document.getElementById("server-url");
    const url = input ? input.value.trim() : "";
    setSavedServerUrl(url);
    logLine(url ? `server saved: ${url}` : "server URL cleared");
  });
  const editor = document.getElementById("page-json");
  if (editor) {
    editor.addEventListener("focus", () => {
      editor.dataset.editing = "true";
    });
    editor.addEventListener("blur", () => {
      editor.dataset.editing = "false";
    });
    editor.addEventListener("input", () => {
      editor.dataset.dirty = "true";
      editor.dataset.userEdited = "true";
    });
  }
  document.getElementById("page-json-apply").addEventListener("click", () => {
    applyPageJson().catch((err) => logLine(`apply failed: ${err.message}`));
  });
  document.getElementById("page-json-reset").addEventListener("click", resetPageJson);
  setInterval(refresh, 1000);
  refresh().catch((err) => logLine(`refresh failed: ${err.message}`));
}

boot();
