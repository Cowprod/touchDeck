/*
  ESP32-C3 generic display demo firmware.

  What it does:
  - connects to Wi-Fi
  - announces itself to the demo server
  - sends telemetry periodically
  - lets you trigger page changes from Serial

  This sketch is intentionally generic. It does not depend on a specific display
  library yet. We can add the actual screen adapter after the hardware choice is fixed.
*/

#include <WiFi.h>
#include <Arduino_GFX_Library.h>
#include <ESPmDNS.h>
#include <Wire.h>
#include <bb_captouch.h>
#include "FreeSansBold10pt7b.h"
#include "FreeMono8pt7b.h"

static const char* WIFI_SSID = "CL07";
static const char* WIFI_PASS = "22072002";
static const char* SERVER_URL = "";
static const char* SERVER_MDNS_TYPE = "http";
static const char* SERVER_MDNS_PROTO = "tcp";
static const char* SERVER_MDNS_HINT = "demo";
static const char* DEVICE_NAME = "esp32c3-display";
static const char* FW_VERSION = "0.1.2";

static const int TFT_SCLK = 6;
static const int TFT_MOSI = 7;
static const int TFT_DC = 2;
static const int TFT_CS = 10;
static const int TFT_BL = 3;
static const int TOUCH_I2C_SDA = 4;
static const int TOUCH_I2C_SCL = 5;
static const int TOUCH_INT_PIN = 0;
static const int TOUCH_RST_PIN = 1;
static const uint8_t TOUCH_I2C_ADDR = 0x15;

static const unsigned long TELEMETRY_PERIOD_MS = 5000;
static const unsigned long WIFI_RETRY_MS = 5000;
static const unsigned long DISPLAY_REFRESH_MS = 2500;
static const int OPTIONAL_NEXT_BUTTON_PIN = -1;
static bool debugVerbose = true;
static const unsigned long EVENTS_RETRY_MS = 2000;

unsigned long lastTelemetryAt = 0;
unsigned long lastWifiRetryAt = 0;
unsigned long lastButtonSampleAt = 0;
bool lastButtonPressed = false;
bool helloSent = false;
bool wifiConnectInFlight = false;
unsigned long lastHelloAt = 0;
bool touchReady = false;
bool touchWasActive = false;
bool touchSwipeSent = false;
uint16_t touchDownX = 0;
uint16_t touchDownY = 0;
BBCapTouch touch;

String deviceIp = "";
Arduino_GFX *gfx = nullptr;
String lastScreenRender;
unsigned long lastDisplayRefreshAt = 0;
float lastTempC = NAN;
long lastWifiRssi = 0;
String serverStatusLine = "SRV --";
String serverStatusDetail = "--";
String serverDisplayLabel = "";
String preferredServerName = "";
String preferredServerHost = "";
uint16_t preferredServerPort = 0;
char serverHost[64] = {0};
uint16_t serverPort = 3131;
unsigned long lastDisplayFetchAt = 0;
static const unsigned long DISPLAY_FETCH_PERIOD_MS = 250;
static const unsigned long HELLO_RETRY_MS = 10000;
bool mdnsReady = false;
unsigned long serverClockOffsetMs = 0;
bool serverClockSynced = false;
unsigned long remotePageRevisionMs = 0;
unsigned long lastSeenPageRevisionMs = 0;
WiFiClient eventsClient;
String eventsLine;
String eventsData;
String eventsType;
bool eventsHeadersDone = false;
unsigned long lastEventsAttemptAt = 0;
String remoteDisplayTitle;
String remoteDisplaySubtitle;
String remoteDisplayLine1;
String remoteDisplayLine2;
String remoteDisplayLine3;

void sendSwipe(const char* dir);
void clearDiscoveredServerTarget();
void refreshDisplay(bool force = false);
bool connectDisplayEvents();
void processDisplayEvents();
String jsonStringField(const char* key, const String& value, bool last);
String jsonIntField(const char* key, long value, bool last);
String jsonNumberField(const char* key, double value, bool last);
int postJson(const String& endpoint, const String& payload, String* responseBody);

struct DisplayLineParts {
  String kind;
  String label;
  String value;
  uint8_t textSize = 1;
};

void logNetState(const char* stage) {
  if (!debugVerbose) return;
  Serial.print("[net] ");
  Serial.print(stage);
  Serial.print(" target=");
  Serial.print(serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost));
  Serial.print(":");
  Serial.print(serverPort);
  Serial.print(" ip=");
  Serial.print(serverHost);
  Serial.print(" pref=");
  if (preferredServerName.length() > 0) {
    Serial.print(preferredServerName);
  } else {
    Serial.print("-");
  }
  Serial.print(" url=");
  if (preferredServerHost.length() > 0) {
    Serial.print(preferredServerHost);
    if (preferredServerPort > 0) {
      Serial.print(":");
      Serial.print(preferredServerPort);
    }
  } else {
    Serial.print("-");
  }
  Serial.println();
}

unsigned long parseUnsignedField(const String& body, const char* key) {
  const String needle = String("\"") + key + "\":";
  const int pos = body.indexOf(needle);
  if (pos < 0) return 0;
  int start = pos + needle.length();
  while (start < (int)body.length() && (body[start] == ' ' || body[start] == '"')) start++;
  int end = start;
  while (end < (int)body.length() && isDigit(body[end])) end++;
  return body.substring(start, end).toInt();
}

void clearDiscoveredServerTarget() {
  if (preferredServerName.length() > 0 || preferredServerHost.length() > 0) {
    return;
  }
  serverHost[0] = '\0';
  serverPort = 0;
  serverDisplayLabel = "";
}

DisplayLineParts splitLine(const String& line) {
  DisplayLineParts parts;
  const int firstSep = line.indexOf('|');
  const int secondSep = firstSep >= 0 ? line.indexOf('|', firstSep + 1) : -1;
  if (firstSep >= 0 && secondSep >= 0) {
    parts.kind = line.substring(0, firstSep);
    parts.label = line.substring(firstSep + 1, secondSep);
    parts.value = line.substring(secondSep + 1);
    parts.kind.trim();
    parts.label.trim();
    parts.value.trim();
    if (parts.label.startsWith("size=")) {
      parts.textSize = (uint8_t)parts.label.substring(5).toInt();
      if (parts.textSize == 0) parts.textSize = 1;
      parts.label = "";
    }
  } else {
    const int colon = line.indexOf(':');
    if (colon >= 0) {
      parts.label = line.substring(0, colon);
      parts.value = line.substring(colon + 1);
      parts.label.trim();
      parts.value.trim();
    } else {
      parts.label = line;
      parts.value = "";
    }
  }
  if (parts.kind.length() == 0) {
    if (parts.label.equalsIgnoreCase("Gain") || parts.label.equalsIgnoreCase("Backlight")) {
      parts.kind = "slider";
    } else if (parts.label.equalsIgnoreCase("Mute")) {
      parts.kind = "toggle";
    } else if (parts.label.equalsIgnoreCase("Preset")) {
      parts.kind = "selector";
    } else if (parts.label.equalsIgnoreCase("Wi-Fi") || parts.label.equalsIgnoreCase("Heap") || parts.label.equalsIgnoreCase("Chip temp")) {
      parts.kind = "meter";
    } else {
      parts.kind = "text";
    }
  }
  if (parts.value.length() == 0 && parts.kind == "title") {
    parts.label = parts.kind;
    parts.kind = "text";
  } else {
    parts.kind.trim();
  }
  return parts;
}

void drawCenteredText(int16_t centerX, int16_t y, const String& text, uint16_t color, uint8_t size) {
  if (!gfx || text.length() == 0) return;
  gfx->setFont(&FreeMono8pt7b);
  gfx->setTextColor(color);
  gfx->setTextSize(size);
  int16_t x1 = 0, y1 = 0;
  uint16_t w = 0, h = 0;
  gfx->getTextBounds(text.c_str(), 0, y, &x1, &y1, &w, &h);
  const int16_t x = centerX - (int16_t)w / 2;
  gfx->setCursor(x, y);
  gfx->println(text);
}

void drawRightAlignedText(int16_t rightX, int16_t y, const String& text, uint16_t color, uint8_t size) {
  if (!gfx || text.length() == 0) return;
  gfx->setFont(&FreeMono8pt7b);
  gfx->setTextColor(color);
  gfx->setTextSize(size);
  int16_t x1 = 0, y1 = 0;
  uint16_t w = 0, h = 0;
  gfx->getTextBounds(text.c_str(), 0, y, &x1, &y1, &w, &h);
  const int16_t x = rightX - (int16_t)w;
  gfx->setCursor(x, y);
  gfx->println(text);
}

uint16_t variantColor(const String& variant) {
  if (variant.equalsIgnoreCase("success")) return gfx->color565(54, 118, 80);
  if (variant.equalsIgnoreCase("warning")) return gfx->color565(154, 117, 48);
  if (variant.equalsIgnoreCase("danger")) return gfx->color565(159, 63, 63);
  if (variant.equalsIgnoreCase("secondary")) return gfx->color565(86, 98, 112);
  if (variant.equalsIgnoreCase("light")) return gfx->color565(222, 230, 236);
  return gfx->color565(42, 54, 108);
}

uint16_t buttonTextColor(const String& variant) {
  if (variant.equalsIgnoreCase("light")) return RGB565_BLACK;
  return RGB565_WHITE;
}

void drawButtonPill(int16_t x, int16_t y, int16_t w, int16_t h, const String& text, const String& variant) {
  gfx->fillRoundRect(x, y, w, h, h / 2, variantColor(variant));
  gfx->drawRoundRect(x, y, w, h, h / 2, RGB565_WHITE);
  gfx->setTextColor(buttonTextColor(variant));
  gfx->setTextSize(1);
  int16_t x1 = 0, y1 = 0;
  uint16_t tw = 0, th = 0;
  gfx->getTextBounds(text.c_str(), 0, y + 8, &x1, &y1, &tw, &th);
  gfx->setCursor(x + (w - (int16_t)tw) / 2, y + 8);
  gfx->println(text);
}

void drawValuePill(int16_t x, int16_t y, int16_t w, int16_t h, const String& text, uint16_t fill, uint16_t textColor) {
  gfx->fillRoundRect(x, y, w, h, h / 2, fill);
  gfx->drawRoundRect(x, y, w, h, h / 2, RGB565_WHITE);
  gfx->setTextColor(textColor);
  gfx->setTextSize(1);
  gfx->setCursor(x + 8, y + 8);
  gfx->println(text);
}

void drawPercentBar(int16_t x, int16_t y, int16_t w, int16_t h, int percent) {
  percent = constrain(percent, 0, 100);
  gfx->drawRoundRect(x, y, w, h, h / 2, gfx->color565(120, 132, 144));
  gfx->fillRoundRect(x + 1, y + 1, (w - 2) * percent / 100, h - 2, (h - 2) / 2, gfx->color565(140, 243, 255));
  if (percent > 12) {
    gfx->drawFastVLine(x + 1 + ((w - 2) * percent / 100) - 2, y + 1, h - 2, gfx->color565(185, 245, 200));
  }
}

void drawGraphicalScreen(const String& title, const String& line1, const String& line2, const String& line3, const String& line4) {
  if (!gfx) return;
  gfx->fillScreen(RGB565_BLACK);
  gfx->setTextWrap(false);
  gfx->setFont(&FreeMono8pt7b);

  const int16_t cardX = 15;
  const int16_t cardW = 210;
  const int16_t cardH = 27;
  const int16_t gap = 5;
  const int16_t cardStartY = 55;
  const uint8_t bodyTextSize = 1;
  String header = String(title);
  header.toUpperCase();

  drawCenteredText(120, 37, header, RGB565_WHITE, 2);

  const String lines[4] = {line1, line2, line3, line4};
  int16_t currentY = cardStartY;
  for (int i = 0; i < 4; ++i) {
    if (lines[i].length() == 0) continue;
    const int16_t y = currentY;
    DisplayLineParts parts = splitLine(lines[i]);
    const int16_t renderedCardH = (parts.label.length() == 0 && parts.value.length() > 0 && parts.textSize >= 2)
      ? cardH + 8
      : cardH;
    gfx->fillRoundRect(cardX, y, cardW, renderedCardH, 8, gfx->color565(24, 30, 36));
    gfx->drawRoundRect(cardX, y, cardW, renderedCardH, 8, gfx->color565(118, 128, 138));

    const bool contentOnly = parts.label.length() == 0 && parts.value.length() > 0;
    if (!contentOnly) {
      gfx->setFont(&FreeMono8pt7b);
      gfx->setTextColor(RGB565_WHITE);
      gfx->setTextSize(bodyTextSize);
      gfx->setCursor(cardX + 8, y + 16);
      gfx->println(parts.label);
    }

    if (parts.kind.equalsIgnoreCase("slider") && parts.value.endsWith("%")) {
      const int pct = parts.value.substring(0, parts.value.length() - 1).toInt();
      drawPercentBar(cardX + 84, y + 8, 105, 10, pct);
    } else if (parts.kind.equalsIgnoreCase("slider")) {
      int pct = parts.value.toFloat() * 100.0f;
      if (pct < 0) pct = 0;
      if (pct > 100) pct = 100;
      drawPercentBar(cardX + 84, y + 8, 105, 10, pct);
    } else if (parts.kind.equalsIgnoreCase("toggle")) {
      const bool on = parts.value.equalsIgnoreCase("ON");
      drawValuePill(cardX + 131, y + 6, 60, 15, parts.value, on ? gfx->color565(156, 64, 64) : gfx->color565(54, 82, 164), RGB565_WHITE);
    } else if (parts.kind.equalsIgnoreCase("selector")) {
      drawRightAlignedText(cardX + 197, y + 17, parts.value, RGB565_WHITE, bodyTextSize);
    } else if (parts.kind.equalsIgnoreCase("button")) {
      String variant = "primary";
      if (parts.label.startsWith("variant=")) {
        variant = parts.label.substring(8);
      }
      drawButtonPill(cardX + 8, y + 5, 194, 17, parts.value, variant);
    } else if (parts.kind.equalsIgnoreCase("meter") && parts.value.length() > 0) {
      gfx->setFont(&FreeMono8pt7b);
      gfx->setTextColor(gfx->color565(222, 228, 232));
      gfx->setTextSize(bodyTextSize);
      gfx->setCursor(cardX + 92, y + 17);
      gfx->println(parts.value);
      String unit = "";
      if (parts.value.endsWith("C")) unit = "C";
      if (parts.value.endsWith("dBm")) unit = "dBm";
      if (unit.length() > 0) {
        drawValuePill(cardX + 173, y + 6, 32, 15, unit, gfx->color565(42, 54, 108), RGB565_WHITE);
      }
    } else if (contentOnly) {
      gfx->setFont(&FreeMono8pt7b);
      gfx->setTextColor(RGB565_WHITE);
      gfx->setTextSize(parts.textSize);
      gfx->setCursor(cardX + 8, y + 26);
      gfx->println(parts.value);
    } else if (parts.value.length() > 0) {
      gfx->setFont(&FreeMono8pt7b);
      gfx->setTextColor(RGB565_WHITE);
      gfx->setTextSize(bodyTextSize);
      gfx->setCursor(cardX + 92, y + 17);
      gfx->println(parts.value);
    }
    currentY += renderedCardH + gap;
  }
}

void updateServerStatus(bool ok, const char *suffix) {
  String label = serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost);
  if (label.length() == 0) label = "mdns";
  if (serverPort > 0 && label.indexOf(':') < 0) {
    label += ":";
    label += String(serverPort);
  }
  if (label.length() > 12) {
    label = label.substring(0, 9) + "...";
  }
  if (ok) {
    serverStatusDetail = (suffix && suffix[0] != '\0') ? String(suffix) : String("OK");
    serverStatusLine = String("SRV ") + label + " " + suffix;
  } else {
    const char *state = (suffix && suffix[0] != '\0') ? suffix : "ERR";
    serverStatusDetail = String(state);
    serverStatusLine = String("SRV ") + label + " " + state;
  }
  Serial.print("[status] ");
  Serial.println(serverStatusLine);
}

void parseServerUrl() {
  String url = SERVER_URL;
  serverDisplayLabel = "";
  preferredServerName = "";
  preferredServerHost = "";
  preferredServerPort = 0;
  serverHost[0] = '\0';
  serverPort = 0;
  if (url.length() == 0) {
    return;
  }
  url.replace("http://", "");
  int slash = url.indexOf('/');
  if (slash >= 0) url = url.substring(0, slash);
  int colon = url.lastIndexOf(':');
  String host = url;
  uint16_t port = 80;
  if (colon >= 0) {
    host = url.substring(0, colon);
    port = (uint16_t)url.substring(colon + 1).toInt();
    if (port == 0) port = 80;
  }
  strlcpy(serverHost, host.c_str(), sizeof(serverHost));
  serverPort = port;
  serverDisplayLabel = host;
  if (serverPort > 0) {
    serverDisplayLabel += ":";
    serverDisplayLabel += String(serverPort);
  }
}

bool resolveServerFromMdns() {
  if (serverHost[0] != '\0' || WiFi.status() != WL_CONNECTED) return serverHost[0] != '\0';
  if (!mdnsReady) {
    if (!MDNS.begin(DEVICE_NAME)) {
      Serial.println("MDNS begin failed");
      return false;
    }
    mdnsReady = true;
  }

  const int count = MDNS.queryService(SERVER_MDNS_TYPE, SERVER_MDNS_PROTO);
  Serial.print("[mdns] services=");
  Serial.println(count);
  if (count <= 0) {
    Serial.println("No mDNS HTTP services found");
    serverStatusLine = "SRV -- MDNS";
    return false;
  }

  int chosen = -1;
  int eligibleCount = 0;
  const bool preferName = preferredServerName.length() > 0;
  const bool preferHost = preferredServerHost.length() > 0;
  for (int i = 0; i < count; ++i) {
    String name = MDNS.instanceName(i);
    String host = MDNS.hostname(i);
    String ipString = MDNS.address(i).toString();
    const uint16_t port = MDNS.port(i);
    Serial.print("[mdns] candidate ");
    Serial.print(i);
    Serial.print(" name=");
    Serial.print(name);
    Serial.print(" host=");
    Serial.print(host);
    Serial.print(" ip=");
    Serial.print(ipString);
    Serial.print(" port=");
    Serial.println(port);
    if (preferName && (name.equalsIgnoreCase(preferredServerName) || host.equalsIgnoreCase(preferredServerName) || ipString.equalsIgnoreCase(preferredServerName))) {
      chosen = i;
      break;
    }
    if (preferHost && (host.equalsIgnoreCase(preferredServerHost) || ipString.equalsIgnoreCase(preferredServerHost))) {
      if (preferredServerPort == 0 || preferredServerPort == port) {
        chosen = i;
        break;
      }
    }
    String probe = name + " " + host;
    probe.toLowerCase();
    if (probe.indexOf(SERVER_MDNS_HINT) >= 0 || probe.indexOf("display") >= 0 || probe.indexOf("demo") >= 0) {
      eligibleCount += 1;
      if (chosen < 0) {
        chosen = i;
      }
    }
  }

  if (chosen < 0 && count == 1) {
    chosen = 0;
    eligibleCount = 1;
    Serial.println("Only one Bonjour HTTP service found; selecting it");
  }

  if (chosen < 0) {
    if (preferHost) {
      IPAddress direct;
      if (direct.fromString(preferredServerHost) && preferredServerPort > 0) {
        strlcpy(serverHost, preferredServerHost.c_str(), sizeof(serverHost));
        serverPort = preferredServerPort;
        serverDisplayLabel = preferredServerName.length() > 0 ? preferredServerName : preferredServerHost;
        Serial.print("[mdns] using direct target ");
        Serial.print(serverHost);
        Serial.print(":");
        Serial.println(serverPort);
        return true;
      }
    }
    Serial.println("No matching Bonjour server preference");
    serverStatusLine = "SRV -- MDNS";
    return false;
  }

  if (!preferName && !preferHost && eligibleCount > 1) {
    Serial.println("Multiple Bonjour services found; using first eligible demo target");
  }

  String host = MDNS.hostname(chosen);
  String serviceHost = MDNS.instanceName(chosen);
  IPAddress ip = MDNS.address(chosen);
  uint16_t port = MDNS.port(chosen);
  if (port == 0) {
    Serial.println("mDNS service missing address or port");
    serverStatusLine = "SRV -- MDNS";
    return false;
  }

  String ipString = ip.toString();
  String chosenHost = ipString;
  IPAddress hostIp;
  if (host.length() > 0 && hostIp.fromString(host)) {
    chosenHost = host;
  } else if (ip == INADDR_NONE && host.length() > 0) {
    chosenHost = host;
  }
  strlcpy(serverHost, chosenHost.c_str(), sizeof(serverHost));
  serverPort = port;
  serverDisplayLabel = serviceHost.length() > 0 ? serviceHost : MDNS.instanceName(chosen);
  if (serverDisplayLabel.length() == 0) {
    serverDisplayLabel = host;
  }
  if (serverDisplayLabel.length() == 0) {
    serverDisplayLabel = chosenHost;
  }
  Serial.print("mDNS server selected: ");
  Serial.print(serverDisplayLabel);
  Serial.print(" @ ");
  Serial.print(serverHost);
  Serial.print(":");
  Serial.println(serverPort);
  logNetState("mdns-selected");
  return true;
}

bool currentServerMatchesPreference() {
  if (preferredServerName.length() > 0) {
    String currentHost = String(serverHost);
    String probe = serverDisplayLabel.length() > 0 ? serverDisplayLabel : currentHost;
    if (probe.equalsIgnoreCase(preferredServerName) || currentHost.equalsIgnoreCase(preferredServerName)) {
      return true;
    }
  }
  if (preferredServerHost.length() > 0) {
    String currentHost = String(serverHost);
    if (!currentHost.equalsIgnoreCase(preferredServerHost)) {
      return false;
    }
    if (preferredServerPort > 0 && preferredServerPort != serverPort) {
      return false;
    }
    return true;
  }
  return true;
}

bool connectDisplayEvents() {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (!ensureServerTarget()) return false;
  if (eventsClient.connected()) return true;

  const unsigned long now = millis();
  if (now - lastEventsAttemptAt < EVENTS_RETRY_MS) return false;
  lastEventsAttemptAt = now;

  eventsClient.stop();
  eventsHeadersDone = false;
  eventsLine = "";
  eventsData = "";
  eventsType = "";

  if (!eventsClient.connect(serverHost, serverPort)) {
    if (debugVerbose) Serial.println("[events] connect failed");
    return false;
  }

  eventsClient.setNoDelay(true);
  eventsClient.print("GET /api/events HTTP/1.1\r\n");
  eventsClient.print("Host: ");
  eventsClient.print(serverHost);
  eventsClient.print("\r\n");
  eventsClient.print("Accept: text/event-stream\r\n");
  eventsClient.print("Connection: keep-alive\r\n\r\n");
  eventsClient.setTimeout(100);
  Serial.println("[events] connected");
  return true;
}

void handleDisplayEvent(const String& payload) {
  if (payload.length() == 0) return;
  setRemoteDisplayFromText(payload);
  refreshDisplay(true);
  updateServerStatus(true, "EVENT OK");
  Serial.println("[events] display update");
}

void processDisplayEvents() {
  if (!connectDisplayEvents()) return;
  while (eventsClient.connected() && eventsClient.available()) {
    String line = eventsClient.readStringUntil('\n');
    line.replace("\r", "");
    line.trim();

    if (!eventsHeadersDone) {
      if (line.length() == 0) {
        eventsHeadersDone = true;
      }
      continue;
    }

    if (line.startsWith("event:")) {
      eventsType = line.substring(6);
      eventsType.trim();
    } else if (line.startsWith("data:")) {
      if (eventsData.length() > 0) eventsData += "\n";
      eventsData += line.substring(5);
      eventsData.trim();
    } else if (line.length() == 0) {
      if (eventsType.equalsIgnoreCase("display")) {
        handleDisplayEvent(eventsData);
      }
      eventsType = "";
      eventsData = "";
    }
  }

  if (!eventsClient.connected() && !eventsClient.available()) {
    eventsClient.stop();
    eventsHeadersDone = false;
    eventsLine = "";
    eventsData = "";
    eventsType = "";
  }
}

bool ensureServerTarget() {
  if (serverHost[0] != '\0' && serverPort > 0) return true;
  return resolveServerFromMdns();
}

bool wifiCredentialsReady() {
  return WIFI_SSID[0] != '\0' &&
         WIFI_PASS[0] != '\0' &&
         String(WIFI_SSID) != "YOUR_WIFI_SSID" &&
         String(WIFI_PASS) != "YOUR_WIFI_PASSWORD";
}

bool initTouch() {
  Wire.end();
  int ok = touch.init(TOUCH_I2C_SDA, TOUCH_I2C_SCL, TOUCH_RST_PIN, TOUCH_INT_PIN);
  if (ok != 0) {
    Serial.println("Touch controller not found");
    touchReady = false;
    return false;
  }

  touch.setOrientation(0, 240, 240);
  touchReady = true;
  Serial.print("Touch ready, sensor type=");
  Serial.println(touch.sensorType());
  return true;
}

void handleTouch() {
  if (!touchReady) return;
  TOUCHINFO ti;
  const bool active = touch.getSamples(&ti) && ti.count > 0;

  if (active) {
    const uint16_t x = ti.x[0];
    const uint16_t y = ti.y[0];
    if (!touchWasActive) {
      touchDownX = x;
      touchDownY = y;
      touchSwipeSent = false;
      Serial.print("touch down x=");
      Serial.print(x);
      Serial.print(" y=");
      Serial.println(y);
    } else if (!touchSwipeSent) {
      const int dx = (int)x - (int)touchDownX;
      const int dy = (int)y - (int)touchDownY;
      if (abs(dx) > 55 && abs(dx) > abs(dy) + 15) {
        Serial.print("touch swipe dx=");
        Serial.print(dx);
        Serial.print(" dy=");
        Serial.println(dy);
        sendSwipe(dx < 0 ? "next" : "prev");
        touchSwipeSent = true;
      }
    }
  }

  touchWasActive = active;
  if (!active) {
    touchSwipeSent = false;
  }
}

void showStatusScreen(const char *title, const char *line1, const char *line2 = "", const char *line3 = "", const char *footer = "") {
  String t = title ? String(title) : String("");
  String l1 = line1 ? String(line1) : String("");
  String l2 = line2 ? String(line2) : String("");
  String l3 = line3 ? String(line3) : String("");
  String f = footer ? String(footer) : String("");
  String render = t + "\n" + l1 + "\n" + l2 + "\n" + l3 + "\n" + f;
  if (render == lastScreenRender) return;
  lastScreenRender = render;
  if (debugVerbose) {
    Serial.print("[screen] ");
    Serial.print(t);
    Serial.print(" | ");
    Serial.print(l1);
    Serial.print(" | ");
    Serial.print(l2);
    Serial.print(" | ");
    Serial.print(l3);
    Serial.print(" | ");
    Serial.println(f);
  }
  drawGraphicalScreen(t, l1, l2, l3, f);
}

bool initDisplay() {
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);

  Arduino_DataBus *bus = new Arduino_ESP32SPI(TFT_DC, TFT_CS, TFT_SCLK, TFT_MOSI, GFX_NOT_DEFINED);
  gfx = new Arduino_GC9A01(bus, GFX_NOT_DEFINED, 0, true);

  if (!gfx->begin()) {
    Serial.println("Display begin failed");
    return false;
  }

  gfx->setRotation(0);
  gfx->fillScreen(RGB565_RED);
  delay(200);
  gfx->fillScreen(RGB565_GREEN);
  delay(200);
  gfx->fillScreen(RGB565_BLUE);
  delay(200);
  showStatusScreen("BOOT", "ESP32-C3 display ready", "boot sequence ok", "", FW_VERSION);
  return true;
}

float readChipTemperatureC() {
#if defined(ARDUINO_ARCH_ESP32)
  return temperatureRead();
#else
  return NAN;
#endif
}

String jsonEscape(const String& s) {
  String out;
  out.reserve(s.length() + 8);
  for (size_t i = 0; i < s.length(); ++i) {
    const char c = s[i];
    switch (c) {
      case '\\': out += "\\\\"; break;
      case '"': out += "\\\""; break;
      case '\n': out += "\\n"; break;
      case '\r': out += "\\r"; break;
      case '\t': out += "\\t"; break;
      default: out += c; break;
    }
  }
  return out;
}

String jsonStringField(const char* key, const String& value, bool last = false) {
  String out = "\"";
  out += key;
  out += "\":\"";
  out += jsonEscape(value);
  out += "\"";
  if (!last) out += ",";
  return out;
}

String jsonNumberField(const char* key, double value, bool last = false) {
  String out = "\"";
  out += key;
  out += "\":";
  if (isnan(value)) {
    out += "null";
  } else {
    out += String(value, 3);
  }
  if (!last) out += ",";
  return out;
}

String jsonIntField(const char* key, long value, bool last = false) {
  String out = "\"";
  out += key;
  out += "\":";
  out += String(value);
  if (!last) out += ",";
  return out;
}

String makeHelloPayload() {
  String ip = WiFi.isConnected() ? WiFi.localIP().toString() : String("");
  const float tempC = readChipTemperatureC();
  const long heapFree = ESP.getFreeHeap();
  const long heapTotal = ESP.getHeapSize();
  const long rssi = WiFi.isConnected() ? WiFi.RSSI() : 0;
  String payload = "{";
  payload += jsonStringField("type", "hello");
  payload += jsonStringField("device", DEVICE_NAME);
  payload += jsonStringField("fw", FW_VERSION);
  payload += jsonStringField("ip", ip);
  payload += jsonNumberField("temp_c", tempC);
  payload += jsonIntField("wifi_rssi", rssi);
  payload += jsonIntField("heap_free", heapFree);
  payload += jsonIntField("heap_total", heapTotal);
  payload += String("\"screen\":{\"w\":240,\"h\":240,\"touch\":") + (touchReady ? "true" : "false") + "}";
  payload += "}";
  return payload;
}

String makeTelemetryPayload() {
  const float tempC = readChipTemperatureC();
  const long heapFree = ESP.getFreeHeap();
  const long heapTotal = ESP.getHeapSize();
  const long rssi = WiFi.isConnected() ? WiFi.RSSI() : 0;

  String payload = "{";
  payload += jsonStringField("type", "telemetry");
  payload += jsonStringField("device", DEVICE_NAME);
  payload += jsonStringField("fw", FW_VERSION);
  payload += jsonStringField("status", serverStatusLine);
  payload += jsonIntField("uptime_ms", millis());
  payload += jsonNumberField("temp_c", tempC);
  payload += jsonIntField("wifi_rssi", rssi);
  payload += jsonIntField("heap_free", heapFree);
  payload += jsonIntField("heap_total", heapTotal);
  payload += jsonStringField("ip", WiFi.isConnected() ? WiFi.localIP().toString() : String(""));
  payload += jsonStringField("ssid", WiFi.isConnected() ? WiFi.SSID() : String(""), true);
  payload += "}";
  return payload;
}

int postJson(const String& endpoint, const String& payload, String* responseBody = nullptr) {
  if (!ensureServerTarget()) {
    Serial.println("No server target available");
    serverStatusLine = "SRV -- MDNS";
    return -1;
  }
  logNetState(("post " + endpoint).c_str());
  WiFiClient client;
  if (!client.connect(serverHost, serverPort)) {
    Serial.println("TCP connect failed");
    serverStatusLine = "SRV " + (serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost)) + " TCP";
    logNetState("tcp-fail");
    clearDiscoveredServerTarget();
    return -1;
  }
  client.print("POST ");
  client.print(endpoint);
  client.println(" HTTP/1.1");
  client.print("Host: ");
  client.println(serverHost);
  client.println("Connection: close");
  client.println("Content-Type: application/json");
  client.print("Content-Length: ");
  client.println(payload.length());
  client.println();
  client.print(payload);

  int status = -1;
  bool headersDone = false;
  if (responseBody) responseBody->remove(0);
  unsigned long start = millis();
  while (millis() - start < 2000) {
    if (!client.available()) {
      if (!client.connected()) break;
      delay(1);
      continue;
    }

    String line = client.readStringUntil('\n');
    line.trim();
    if (line.startsWith("HTTP/")) {
      int sp = line.indexOf(' ');
      if (sp >= 0) {
        status = line.substring(sp + 1, sp + 4).toInt();
      }
    } else if (line.length() == 0) {
      headersDone = true;
    } else if (headersDone && responseBody) {
      *responseBody += line;
      *responseBody += '\n';
    }
  }

  client.stop();
  if (responseBody && responseBody->endsWith("\n")) responseBody->remove(responseBody->length() - 1);
  if (debugVerbose) {
    Serial.print("HTTP ");
    Serial.print(status);
    Serial.print(" ");
    Serial.println(endpoint);
  }
  return status;
}

bool getText(const String& endpoint, String& body, int& status) {
  if (!ensureServerTarget()) {
    Serial.println("No server target available");
    status = -1;
    serverStatusLine = "SRV -- MDNS";
    return false;
  }
  logNetState(("get " + endpoint).c_str());
  WiFiClient client;
  if (!client.connect(serverHost, serverPort)) {
    Serial.println("TCP connect failed");
    status = -1;
    serverStatusLine = "SRV " + (serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost)) + " TCP";
    logNetState("tcp-fail");
    clearDiscoveredServerTarget();
    return false;
  }

  client.print("GET ");
  client.print(endpoint);
  client.println(" HTTP/1.1");
  client.print("Host: ");
  client.println(serverHost);
  client.println("Connection: close");
  client.println();

  status = -1;
  bool headersDone = false;
  body = "";
  unsigned long start = millis();
  while (millis() - start < 2500) {
    if (!client.available()) {
      if (!client.connected()) break;
      delay(1);
      continue;
    }

    String line = client.readStringUntil('\n');
    line.trim();
    if (!headersDone) {
      if (line.startsWith("HTTP/")) {
        int sp = line.indexOf(' ');
        if (sp >= 0) {
          status = line.substring(sp + 1, sp + 4).toInt();
        }
      } else if (line.length() == 0) {
        headersDone = true;
      }
      continue;
    }

    if (line.length() > 0) {
      body += line;
      body += '\n';
    }
  }

  client.stop();
  if (body.endsWith("\n")) body.remove(body.length() - 1);
  if (debugVerbose) {
    Serial.print("HTTP ");
    Serial.print(status);
    Serial.print(" ");
    Serial.println(endpoint);
  }
  return status >= 200 && status < 300;
}

void clearRemoteDisplay() {
  remoteDisplayTitle = "";
  remoteDisplaySubtitle = "";
  remoteDisplayLine1 = "";
  remoteDisplayLine2 = "";
  remoteDisplayLine3 = "";
}

void setRemoteDisplayFromText(const String& body) {
  clearRemoteDisplay();
  int start = 0;
  String fallback[5];
  int fallbackCount = 0;

  while (start <= body.length()) {
    int nl = body.indexOf('\n', start);
    String part = nl >= 0 ? body.substring(start, nl) : body.substring(start);
    part.trim();

    if (part.startsWith("title=")) {
      remoteDisplayTitle = part.substring(6);
      remoteDisplayTitle.trim();
    } else if (part.startsWith("pagever=")) {
      remotePageRevisionMs = (unsigned long)part.substring(8).toInt();
    } else if (part.startsWith("serverpref=")) {
      String pref = part.substring(11);
      pref.trim();
      preferredServerName = pref;
      Serial.print("preferred server name=");
      Serial.println(preferredServerName);
    } else if (part.startsWith("serverurl=")) {
      String target = part.substring(10);
      target.trim();
      int colon = target.lastIndexOf(':');
      preferredServerHost = target;
      preferredServerPort = 0;
      if (colon >= 0) {
        preferredServerHost = target.substring(0, colon);
        preferredServerPort = (uint16_t)target.substring(colon + 1).toInt();
      }
      Serial.print("preferred server url=");
      Serial.println(target);
    } else if (part.startsWith("line1=")) {
      remoteDisplaySubtitle = part.substring(6);
      remoteDisplaySubtitle.trim();
    } else if (part.startsWith("line2=")) {
      remoteDisplayLine1 = part.substring(6);
      remoteDisplayLine1.trim();
    } else if (part.startsWith("line3=")) {
      remoteDisplayLine2 = part.substring(6);
      remoteDisplayLine2.trim();
    } else if (part.startsWith("line4=")) {
      remoteDisplayLine3 = part.substring(6);
      remoteDisplayLine3.trim();
    } else if (part.length() > 0 && fallbackCount < 5) {
      fallback[fallbackCount++] = part;
    }

    if (nl < 0) break;
    start = nl + 1;
  }

  if (remoteDisplayTitle.length() == 0 && fallbackCount > 0) remoteDisplayTitle = fallback[0];
  if (remoteDisplaySubtitle.length() == 0 && fallbackCount > 1) remoteDisplaySubtitle = fallback[1];
  if (remoteDisplayLine1.length() == 0 && fallbackCount > 2) remoteDisplayLine1 = fallback[2];
  if (remoteDisplayLine2.length() == 0 && fallbackCount > 3) remoteDisplayLine2 = fallback[3];
  if (remoteDisplayLine3.length() == 0 && fallbackCount > 4) remoteDisplayLine3 = fallback[4];
}

void fetchRemoteDisplay() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!ensureServerTarget()) return;
  if (millis() - lastDisplayFetchAt < DISPLAY_FETCH_PERIOD_MS) return;
  lastDisplayFetchAt = millis();

  String body;
  int status = -1;
  if (getText("/api/display.txt", body, status)) {
    if (debugVerbose) {
      Serial.print("[display] ");
      Serial.println(body);
    }
    setRemoteDisplayFromText(body);
    if (remotePageRevisionMs > 0 && remotePageRevisionMs != lastSeenPageRevisionMs) {
      lastSeenPageRevisionMs = remotePageRevisionMs;
      unsigned long nowServerMs = serverClockSynced ? (serverClockOffsetMs + millis()) : 0;
      if (serverClockSynced && nowServerMs >= remotePageRevisionMs) {
        Serial.print("[page] rev=");
        Serial.print(remotePageRevisionMs);
        Serial.print(" latency_ms=");
        Serial.println(nowServerMs - remotePageRevisionMs);
      } else {
        Serial.print("[page] rev=");
        Serial.println(remotePageRevisionMs);
      }
      refreshDisplay(true);
    }
    if (!currentServerMatchesPreference()) {
      Serial.println("Switching to preferred Bonjour server");
      serverHost[0] = '\0';
      serverPort = 0;
      serverDisplayLabel = "";
      resolveServerFromMdns();
    }
    updateServerStatus(true, "DISPLAY OK");
  } else if (status >= 0) {
    updateServerStatus(false, "DISPLAY ERR");
  }
}

void connectWifi() {
  if (!wifiCredentialsReady()) return;
  if (WiFi.status() == WL_CONNECTED) {
    wifiConnectInFlight = false;
    return;
  }

  const unsigned long now = millis();
  if (wifiConnectInFlight && now - lastWifiRetryAt < WIFI_RETRY_MS) return;
  if (now - lastWifiRetryAt < WIFI_RETRY_MS) return;

  lastWifiRetryAt = millis();
  wifiConnectInFlight = true;

  Serial.print("Wi-Fi connecting to ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
}

void announceIfReady() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!ensureServerTarget()) return;
  const unsigned long now = millis();
  if (helloSent && now - lastHelloAt < HELLO_RETRY_MS) return;
  if (debugVerbose) Serial.println("[hello] sending");
  deviceIp = WiFi.localIP().toString();
  String response;
  const unsigned long sentAt = millis();
  const int code = postJson("/api/hello", makeHelloPayload(), &response);
  if (code >= 200 && code < 300) {
    const unsigned long serverTimeMs = parseUnsignedField(response, "serverTimeMs");
    if (serverTimeMs > 0 && sentAt > 0) {
      serverClockOffsetMs = serverTimeMs - sentAt;
      serverClockSynced = true;
    }
    updateServerStatus(true, "HELLO OK");
    refreshDisplay(true);
    helloSent = true;
    lastHelloAt = now;
  } else {
    updateServerStatus(false, "HELLO ERR");
    refreshDisplay(true);
  }
}

void sendTelemetry() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!ensureServerTarget()) return;
  if (debugVerbose) Serial.println("[telemetry] sending");
  const String payload = makeTelemetryPayload();
  if (debugVerbose) {
    Serial.print("[telemetry] payload ");
    Serial.println(payload);
  }
  const int code = postJson("/api/telemetry", payload);
  Serial.print("[telemetry] http=");
  Serial.println(code);
  if (code >= 200 && code < 300) {
    updateServerStatus(true, "TEL OK");
    refreshDisplay(true);
    if (!helloSent) {
      helloSent = true;
      lastHelloAt = millis();
    }
  } else {
    updateServerStatus(false, "TEL ERR");
    refreshDisplay(true);
    if (debugVerbose) Serial.println("[telemetry] failed");
  }
}

void sendSwipe(const char* dir) {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!ensureServerTarget()) return;
  if (debugVerbose) {
    Serial.print("[swipe] sending dir=");
    Serial.println(dir);
  }
  String payload = "{";
  payload += jsonStringField("type", "swipe");
  payload += jsonStringField("device", DEVICE_NAME);
  payload += jsonStringField("dir", dir, true);
  payload += "}";
  const int code = postJson("/api/swipe", payload);
  if (code >= 200 && code < 300) {
    updateServerStatus(true, "SWIPE OK");
  } else {
    updateServerStatus(false, "SWIPE ERR");
  }
}

void handleSerialCommands() {
  while (Serial.available() > 0) {
    const char c = (char)Serial.read();
    if (c == 'n' || c == 'N') {
      sendSwipe("next");
    } else if (c == 'p' || c == 'P') {
      sendSwipe("prev");
    } else if (c == 't' || c == 'T') {
      sendTelemetry();
    } else if (c == 'h' || c == 'H') {
      announceIfReady();
    } else if (c == 'd' || c == 'D') {
      debugVerbose = !debugVerbose;
      Serial.print("[debug] verbose=");
      Serial.println(debugVerbose ? "on" : "off");
    }
  }
}

void handleOptionalButton() {
  if (OPTIONAL_NEXT_BUTTON_PIN < 0) return;
  const unsigned long now = millis();
  if (now - lastButtonSampleAt < 40) return;
  lastButtonSampleAt = now;

  const bool pressed = digitalRead(OPTIONAL_NEXT_BUTTON_PIN) == LOW;
  if (pressed && !lastButtonPressed) {
    sendSwipe("next");
  }
  lastButtonPressed = pressed;
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println();
  Serial.println("ESP32-C3 generic display demo boot");
  Serial.print("[boot] fw=");
  Serial.println(FW_VERSION);

  parseServerUrl();
  if (!ensureServerTarget()) {
    Serial.println("Will try mDNS after Wi-Fi comes up");
  }
  initDisplay();
  initTouch();
  pinMode(OPTIONAL_NEXT_BUTTON_PIN, INPUT_PULLUP);
  connectWifi();
}

void refreshDisplay(bool force) {
  const unsigned long now = millis();
  if (!force && now - lastDisplayRefreshAt < DISPLAY_REFRESH_MS) return;
  lastDisplayRefreshAt = now;

  if (WiFi.status() == WL_CONNECTED) {
    if (remoteDisplayTitle.length() > 0 || remoteDisplaySubtitle.length() > 0 || remoteDisplayLine1.length() > 0) {
      if (debugVerbose) {
        Serial.print("[display-screen] page=");
        Serial.println(remoteDisplayTitle);
      }
      showStatusScreen(
        remoteDisplayTitle.c_str(),
        remoteDisplaySubtitle.c_str(),
        remoteDisplayLine1.c_str(),
        remoteDisplayLine2.c_str(),
        remoteDisplayLine3.c_str()
      );
      return;
    }

    char ipLine[32];
    snprintf(ipLine, sizeof(ipLine), "IP %s", deviceIp.c_str());
    char fwLine[32];
    snprintf(fwLine, sizeof(fwLine), "FW %s", FW_VERSION);
    if (debugVerbose) {
      Serial.print("[display-screen] status=");
      Serial.print(serverStatusDetail);
      Serial.print(" fw=");
      Serial.println(FW_VERSION);
    }
    showStatusScreen("CONNECTED", ipLine, serverStatusDetail.c_str(), fwLine, "");
  } else {
    showStatusScreen("WAITING", "Wi-Fi not connected", "module booted", "", "setup mode");
  }
}

void loop() {
  handleSerialCommands();
  handleTouch();
  handleOptionalButton();
  connectWifi();

  if (WiFi.status() == WL_CONNECTED) {
    ensureServerTarget();
    wifiConnectInFlight = false;
    if (!helloSent) {
      announceIfReady();
    }
    processDisplayEvents();
    // Keep a lightweight HTTP fallback so the page still renders even if the
    // SSE stream is late or temporarily silent.
    fetchRemoteDisplay();
    if (millis() - lastTelemetryAt >= TELEMETRY_PERIOD_MS) {
      lastTelemetryAt = millis();
      sendTelemetry();
    }
  } else {
    deviceIp = "";
    helloSent = false;
    updateServerStatus(false, "WIFI ERR");
    clearRemoteDisplay();
  }

  refreshDisplay();

  delay(10);
}
