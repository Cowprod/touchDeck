const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");
const { Bonjour } = require("bonjour-service");

const PUBLIC_DIR = path.join(__dirname, "public");
const DEFAULT_CONFIG_PATH = path.join(__dirname, "demo.config.json");

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml"
};

const { WebSocketServer } = WebSocket;

const DEFAULT_PAGES = [
  {
    id: "home",
    title: "Home",
    subtitle: "Generic display demo",
    controls: [
      { id: "mode", type: "selector", label: "Mode", value: "demo" },
      { id: "backlight", type: "slider", label: "Backlight", value: 0.92, variable: "backlight" },
      { id: "chars", type: "text", label: "", value: buildCalibrationString(), displaySize: 2 },
      { id: "preview", type: "button", label: "Save preset", value: "demo/save", variant: "primary", webhook: "/api/webhook" },
      { id: "wifi", type: "meter", label: "Wi-Fi", value: -58 }
    ]
  },
  {
    id: "sensors",
    title: "Sensors",
    subtitle: "Telemetry from the module",
    controls: [
      { id: "temp", type: "meter", label: "Chip temp", value: 42.1, unit: "C", min: 20, max: 80 },
      { id: "heap", type: "meter", label: "Heap", value: 0.63, min: 0, max: 1 },
      { id: "uptime", type: "text", label: "Uptime", value: "00:00:00" }
    ]
  },
  {
    id: "controls",
    title: "Controls",
    subtitle: "Example multi-control page",
    controls: [
      { id: "gain", type: "slider", label: "Gain", value: 0.4, variable: "gain" },
      { id: "mute", type: "toggle", label: "Mute", value: false, variable: "mute" },
      { id: "preset", type: "selector", label: "Preset", value: "A", variable: "preset" },
      { id: "fire", type: "button", label: "Fire", value: "note/on", variant: "success", webhook: "/api/webhook" }
    ]
  },
  {
    id: "about",
    title: "About",
    subtitle: "Device and firmware info",
    controls: [
      { id: "fw", type: "text", label: "Firmware", value: "n/a" },
      { id: "ip", type: "text", label: "IP", value: "n/a" },
      { id: "status", type: "text", label: "Status", value: "Waiting for module" },
      { id: "panic", type: "button", label: "Panic", value: "panic", variant: "danger", webhook: "/api/webhook" }
    ]
  }
];

const DEFAULT_CONFIG = {
  name: "ESP32-C3 display demo",
  serviceType: "esp32c3-display",
  port: 3131,
  variables: {
    backlight: 0.92,
    gain: 0.4,
    mute: false,
    preset: "A"
  },
  pages: DEFAULT_PAGES
};

function parseArgs(argv) {
  const out = { configPath: process.env.DEMO_CONFIG || DEFAULT_CONFIG_PATH };
  for (let i = 2; i < argv.length; i += 1) {
    if (argv[i] === "--config" && argv[i + 1]) {
      out.configPath = argv[i + 1];
      i += 1;
    }
  }
  return out;
}

function loadConfig(configPath) {
  let parsed = {};
  try {
    if (fs.existsSync(configPath)) {
      parsed = JSON.parse(fs.readFileSync(configPath, "utf8"));
    }
  } catch (err) {
    console.warn(`[config] failed to load ${configPath}: ${err.message}`);
  }

  const config = {
    ...DEFAULT_CONFIG,
    ...parsed,
    variables: {
      ...DEFAULT_CONFIG.variables,
      ...(parsed.variables || {})
    }
  };
  if (Array.isArray(parsed.pages) && parsed.pages.length > 0) {
    config.pages = parsed.pages;
  }
  config.pages = config.pages.map(normalizePage);
  return config;
}

function normalizeControl(control) {
  if (!control || typeof control !== "object") return null;
  const normalized = {
    ...control,
    id: String(control.id || "").trim(),
    type: String(control.type || "text").trim() || "text",
    label: String(control.label ?? "").trim(),
    value: control.value
  };
  if (!normalized.id) return null;
  if (typeof control.unit === "string" && control.unit.trim().length > 0) {
    normalized.unit = control.unit.trim();
  }
  if (typeof control.displaySize === "number" && Number.isFinite(control.displaySize)) {
    normalized.displaySize = control.displaySize;
  }
  if (typeof control.variable === "string" && control.variable.trim().length > 0) {
    normalized.variable = control.variable.trim();
  }
  if (typeof control.webhook === "string" && control.webhook.trim().length > 0) {
    normalized.webhook = control.webhook.trim();
  }
  if (typeof control.variant === "string" && control.variant.trim().length > 0) {
    normalized.variant = control.variant.trim().toLowerCase();
  }
  return normalized;
}

function normalizePage(page) {
  if (!page || typeof page !== "object") {
    return {
      id: "page",
      title: "Module",
      subtitle: "",
      controls: [],
      variables: {}
    };
  }

  const normalized = {
    id: String(page.id || "page").trim() || "page",
    title: String(page.title || "Module"),
    subtitle: typeof page.subtitle === "string" ? page.subtitle : "",
    controls: Array.isArray(page.controls) ? page.controls.map(normalizeControl).filter(Boolean) : []
  };
  if (page.variables && typeof page.variables === "object" && !Array.isArray(page.variables)) {
    normalized.variables = { ...page.variables };
  }
  return normalized;
}

const args = parseArgs(process.argv);
const config = loadConfig(path.resolve(args.configPath));
const PORT = Number(process.env.PORT || config.port || DEFAULT_CONFIG.port);
const pages = config.pages;

const state = {
  currentPageIndex: 0,
  pageRevision: Date.now(),
  device: null,
  telemetry: null,
  lastControl: null,
  lastSwipe: null,
  lastWebhook: null,
  selectedBonjourService: null,
  lastSeenAt: null,
  variables: { ...config.variables }
};

const sseClients = new Set();
const wsClients = new Set();

function nowIso() {
  return new Date().toISOString();
}

function buildSseDataLines(payload) {
  return String(payload)
    .split(/\r?\n/)
    .map((line) => `data: ${line}`)
    .join("\n");
}

function sendSseEvent(res, eventName, payload) {
  res.write(`event: ${eventName}\n`);
  res.write(`${buildSseDataLines(payload)}\n\n`);
}

function broadcastDisplayUpdate() {
  const body = buildDisplayText();
  console.log(`[events] broadcast display page=${state.currentPageIndex} rev=${state.pageRevision}`);
  for (const res of Array.from(sseClients)) {
    try {
      sendSseEvent(res, "display", body);
    } catch {
      sseClients.delete(res);
    }
  }
  for (const socket of Array.from(wsClients)) {
    try {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(body);
      } else {
        wsClients.delete(socket);
      }
    } catch {
      wsClients.delete(socket);
    }
  }
}

function buildCalibrationString() {
  const tokens = [];
  for (let i = 0; i <= 9; i += 1) {
    tokens.push(String(i));
  }
  for (let code = 65; code <= 90; code += 1) {
    tokens.push(String.fromCharCode(code));
  }
  for (let first = 65; first <= 90; first += 1) {
    for (let second = 65; second <= 90; second += 1) {
      tokens.push(String.fromCharCode(first) + String.fromCharCode(second));
    }
  }
  return tokens.join(" ");
}

function safePathFromUrl(urlPath) {
  const normalized = path.normalize(urlPath).replace(/^(\.\.[/\\])+/, "");
  return path.join(PUBLIC_DIR, normalized);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 1_000_000) {
        reject(new Error("Payload too large"));
      }
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error("Invalid JSON"));
      }
    });
    req.on("error", reject);
  });
}

function clampIndex(index) {
  const len = pages.length;
  return ((index % len) + len) % len;
}

function currentPage() {
  const page = pages[state.currentPageIndex];
  const telemetry = state.telemetry || {};

  return {
    ...page,
    telemetry,
    device: state.device,
    lastControl: state.lastControl,
    lastSwipe: state.lastSwipe,
    lastWebhook: state.lastWebhook,
    selectedBonjourService: state.selectedBonjourService,
    pageRevision: state.pageRevision,
    serverTime: nowIso()
  };
}

function applyPageUpdate(nextPage) {
  if (!nextPage || typeof nextPage !== "object") {
    throw new Error("Invalid page payload");
  }

  const target = pages[state.currentPageIndex];
  if (!target) throw new Error("No current page");

  if (typeof nextPage.id === "string" && nextPage.id.trim() && nextPage.id.trim() !== target.id) {
    throw new Error("Page id cannot be changed");
  }

  target.title = String(nextPage.title ?? target.title ?? "Module");
  target.subtitle = typeof nextPage.subtitle === "string" ? nextPage.subtitle : target.subtitle;
  if (nextPage.variables && typeof nextPage.variables === "object" && !Array.isArray(nextPage.variables)) {
    target.variables = {
      ...(target.variables || {}),
      ...nextPage.variables
    };
    state.variables = {
      ...state.variables,
      ...nextPage.variables
    };
  }

  if (Array.isArray(nextPage.controls)) {
    const controls = nextPage.controls.map(normalizeControl).filter(Boolean).slice(0, 4);
    if (controls.length > 0) {
      target.controls = controls;
      for (const control of controls) {
        if (control.variable) {
          state.variables[control.variable] = control.value;
        }
      }
    }
  }

  refreshDerivedPages();
  state.pageRevision = Date.now();
  broadcastDisplayUpdate();
  return currentPage();
}

function applySwipe(dir) {
  if (dir === "left" || dir === "next") {
    state.currentPageIndex = clampIndex(state.currentPageIndex + 1);
  } else if (dir === "right" || dir === "prev") {
    state.currentPageIndex = clampIndex(state.currentPageIndex - 1);
  }
  state.pageRevision = Date.now();
  state.lastSwipe = { dir, at: nowIso() };
  broadcastDisplayUpdate();
  return currentPage();
}

function enrichAboutPage() {
  const page = pages.find((p) => p.id === "about");
  if (!page) return;
  const ip = state.device?.ip || "n/a";
  const fw = state.device?.fw || "n/a";
  const status = state.device ? "Connected" : "Waiting for module";
  page.controls = [
    { id: "fw", type: "text", label: "Firmware", value: fw },
    { id: "ip", type: "text", label: "IP", value: ip },
    { id: "status", type: "text", label: "Status", value: status }
  ];
}

function enrichSensorPage() {
  const page = pages.find((p) => p.id === "sensors");
  if (!page) return;
  const t = state.telemetry || {};
  const uptime = typeof t.uptime_ms === "number" ? formatUptime(t.uptime_ms) : "00:00:00";
  const temp = typeof t.temp_c === "number" ? t.temp_c : 0;
  const heap = typeof t.heap_free === "number" && typeof t.heap_total === "number"
    ? t.heap_free / t.heap_total
    : 0;
  const wifi = typeof t.wifi_rssi === "number" ? t.wifi_rssi : -100;
  page.controls = [
    { id: "temp", type: "meter", label: "Chip temp", value: temp, unit: "C", min: 20, max: 80 },
    { id: "heap", type: "meter", label: "Heap", value: heap, min: 0, max: 1 },
    { id: "wifi", type: "meter", label: "Wi-Fi", value: wifi, unit: "dBm", min: -100, max: -30 },
    { id: "uptime", type: "text", label: "Uptime", value: uptime }
  ];
}

function refreshDerivedPages() {
  enrichAboutPage();
  enrichSensorPage();
  const home = pages.find((p) => p.id === "home");
  if (home) {
    const backlight = home.controls.find((control) => control.id === "backlight");
    if (backlight && backlight.variable) {
      backlight.value = state.variables[backlight.variable] ?? backlight.value;
    }
  }
  const controlsPage = pages.find((p) => p.id === "controls");
  if (controlsPage) {
    for (const control of controlsPage.controls) {
      if (control.variable) {
        control.value = state.variables[control.variable] ?? control.value;
      }
    }
  }
}

function formatUptime(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const hours = String(Math.floor(total / 3600)).padStart(2, "0");
  const mins = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
  const secs = String(total % 60).padStart(2, "0");
  return `${hours}:${mins}:${secs}`;
}

function formatControlValue(control) {
  if (!control) return "";
  const value = control.variable && Object.prototype.hasOwnProperty.call(state.variables, control.variable)
    ? state.variables[control.variable]
    : control.value;
  if (control.type === "toggle") return value ? "ON" : "OFF";
  if (control.type === "selector") return String(value);
  if (control.type === "slider") {
    if (typeof value === "number") {
      return String(value);
    }
    return String(value ?? "");
  }
  if (control.type === "meter" && typeof value === "number") {
    if (control.unit === "C") return `${value.toFixed(1)} C`;
    if (control.unit === "dBm") return `${value.toFixed(0)} dBm`;
    if (value >= 0 && value <= 1) return `${Math.round(value * 100)}%`;
    return String(value);
  }
  return String(value ?? "");
}

function buildDisplayText() {
  refreshDerivedPages();
  const page = currentPage();
  const lines = [`title=${page.title || "Module"}`];
  lines.push(`pagever=${state.pageRevision}`);
  if (state.selectedBonjourService) {
    const selected = state.selectedBonjourService;
    if (selected.name) lines.push(`serverpref=${selected.name}`);
    if (selected.host && selected.port) lines.push(`serverurl=${selected.host}:${selected.port}`);
  }

  let index = 1;
  for (const control of page.controls || []) {
    const type = control.type || "text";
    const label = control.label || control.id || "item";
    const value = formatControlValue(control);
    if (control.id === "chars") {
      const displaySize = Number(control.displaySize || 1);
      lines.push(`line${index}=text|size=${displaySize}|${String(value).replace(/\s+/g, "")}`);
    } else if (type === "slider") {
      lines.push(`line${index}=slider|${label}|${String(control.variable && state.variables[control.variable] !== undefined ? state.variables[control.variable] : control.value)}`);
    } else if (type === "button") {
      const variant = String(control.variant || "primary").toLowerCase();
      lines.push(`line${index}=button|variant=${variant}|${label}`);
    } else {
      lines.push(`line${index}=${type}|${label}|${value}`);
    }
    if (index >= 4) break;
    index += 1;
  }

  return lines.join("\n");
}

function currentStatePayload() {
  refreshDerivedPages();
  return JSON.stringify({
    ok: true,
    pages: pages.map((p) => ({ id: p.id, title: p.title, subtitle: p.subtitle })),
    currentPageIndex: state.currentPageIndex,
    pageRevision: state.pageRevision,
    page: currentPage(),
    device: state.device,
    telemetry: state.telemetry,
    lastControl: state.lastControl,
    lastSwipe: state.lastSwipe,
    lastWebhook: state.lastWebhook,
    serverTime: nowIso()
  });
}

function sendJson(res, code, body) {
  res.writeHead(code, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(JSON.stringify(body, null, 2));
}

function discoverServices(timeoutMs = 2000, type = DEFAULT_CONFIG.serviceType) {
  return new Promise((resolve) => {
    try {
      const bonjour = new Bonjour();
      const browser = bonjour.find({ type }, () => {});
      const matchesDemoService = (service) => {
        const name = String(service?.name || "").toLowerCase();
        const host = String(service?.host || "").toLowerCase();
        const fqdn = String(service?.fqdn || "").toLowerCase();
        const txt = service?.txt && typeof service.txt === "object" ? JSON.stringify(service.txt).toLowerCase() : "";
        const pageCount = String(service?.txt?.pages || "");
        return (
          name.includes("demo") ||
          name.includes("display") ||
          host.includes("demo") ||
          host.includes("display") ||
          fqdn.includes("demo") ||
          fqdn.includes("display") ||
          txt.includes("demo") ||
          txt.includes("display") ||
          txt.includes("pages") ||
          pageCount.length > 0
        );
      };
      const done = () => {
        try { browser.stop(); } catch {}
        try { bonjour.destroy(); } catch {}
      };

      setTimeout(() => {
        const services = (browser.services || [])
          .filter(matchesDemoService)
          .map((service) => ({
          name: service.name || "",
          host: service.host || "",
          fqdn: service.fqdn || "",
          port: service.port || 0,
          type: service.type || type,
          protocol: service.protocol || "tcp",
          txt: service.txt || {},
          addresses: Array.isArray(service.addresses) ? service.addresses : []
        }));
        done();
        resolve(services);
      }, Math.max(250, Number(timeoutMs) || 2000));
    } catch (err) {
      resolve([{ error: err.message }]);
    }
  });
}

function normalizeBonjourSelection(body) {
  if (!body || typeof body !== "object") return null;
  const selection = {
    name: String(body.name || body.serviceName || body.instanceName || "").trim(),
    host: String(body.host || body.hostname || "").trim(),
    port: Number(body.port || 0),
    url: String(body.url || "").trim()
  };
  if (!selection.name && !selection.host && !selection.url) return null;
  if (!Number.isFinite(selection.port) || selection.port < 0) selection.port = 0;
  return selection;
}

function publishBonjour() {
  if (config.publishBonjour === false) {
    return null;
  }
  try {
    const advertisedHost = String(
      config.bonjourHost ||
      process.env.BONJOUR_HOST ||
      process.env.DEMO_BONJOUR_HOST ||
      ""
    ).trim() || getLocalWifiHost();
    const bonjour = new Bonjour();
    const service = bonjour.publish({
      name: config.name || "ESP32-C3 display demo",
      type: config.serviceType || DEFAULT_CONFIG.serviceType,
      host: advertisedHost || undefined,
      port: PORT,
      txt: {
        path: "/",
        pages: String((config.pages || []).length)
      }
    });
    console.log(`[bonjour] published ${config.name || "ESP32-C3 display demo"} on port ${PORT}${advertisedHost ? ` host=${advertisedHost}` : ""}`);
    return { bonjour, service };
  } catch (err) {
    console.warn(`[bonjour] unavailable: ${err.message}`);
    return null;
  }
}

function getLocalWifiHost() {
  const candidates = [];
  const nets = require("os").networkInterfaces();
  for (const entries of Object.values(nets)) {
    for (const info of entries || []) {
      if (!info || info.internal || info.family !== "IPv4") continue;
      if (!info.address) continue;
      candidates.push(info.address);
    }
  }
  const preferred = candidates.find((ip) => ip.startsWith("192.168.92.")) || candidates.find((ip) => ip.startsWith("192.168."));
  return preferred || candidates[0] || "";
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (req.method === "GET" && url.pathname === "/api/state") {
    refreshDerivedPages();
    sendJson(res, 200, JSON.parse(currentStatePayload()));
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/events") {
    refreshDerivedPages();
    console.log(`[events] client connected from ${req.socket.remoteAddress || "unknown"}`);
    res.writeHead(200, {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no"
    });
    res.write("\n");
    sseClients.add(res);
    sendSseEvent(res, "state", currentStatePayload());
    sendSseEvent(res, "display", buildDisplayText());
    const heartbeat = setInterval(() => {
      try {
        res.write(": ping\n\n");
      } catch {
        clearInterval(heartbeat);
      }
    }, 15000);
    req.on("close", () => {
      clearInterval(heartbeat);
      sseClients.delete(res);
      console.log("[events] client disconnected");
    });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/page") {
    const dir = url.searchParams.get("dir") || "current";
    refreshDerivedPages();
    if (dir === "next" || dir === "prev") {
      sendJson(res, 200, { ok: true, page: applySwipe(dir) });
      return;
    }
    sendJson(res, 200, { ok: true, page: currentPage() });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/display.txt") {
    refreshDerivedPages();
    const body = buildDisplayText();
    res.writeHead(200, {
      "Content-Type": "text/plain; charset=utf-8",
      "Content-Length": Buffer.byteLength(body, "utf8"),
      "Cache-Control": "no-store"
    });
    res.end(body);
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/discovery") {
    const type = url.searchParams.get("type") || config.serviceType || DEFAULT_CONFIG.serviceType;
    const timeoutMs = Number(url.searchParams.get("timeoutMs") || 2000);
    const services = await discoverServices(timeoutMs, type);
    sendJson(res, 200, {
      ok: true,
      type,
      timeoutMs,
      services
    });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/server-target") {
    try {
      const body = await readJsonBody(req);
      const selection = normalizeBonjourSelection(body.service || body);
      if (!selection) {
        throw new Error("Missing server selection");
      }
      state.selectedBonjourService = selection;
      state.lastSeenAt = nowIso();
      sendJson(res, 200, { ok: true, selectedBonjourService: state.selectedBonjourService });
    } catch (err) {
      sendJson(res, 400, { ok: false, error: err.message });
    }
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/webhook") {
    try {
      const body = await readJsonBody(req);
      state.lastWebhook = {
        ...body,
        at: nowIso()
      };
      console.log("[webhook]", body.type || "unknown", body.controlId || "");
      sendJson(res, 200, { ok: true, lastWebhook: state.lastWebhook });
    } catch (err) {
      sendJson(res, 400, { ok: false, error: err.message });
    }
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/hello") {
    try {
      const body = await readJsonBody(req);
      console.log("[hello]", body.device || "unknown", `fw=${body.fw || "unknown"}`, body.ip || "no-ip");
      state.device = {
        device: body.device || "unknown",
        fw: body.fw || "unknown",
        screen: body.screen || null,
        ip: body.ip || null,
        mac: body.mac || null,
        connectedAt: nowIso()
      };
      if (typeof body.temp_c === "number" || typeof body.wifi_rssi === "number") {
        state.telemetry = {
          ...state.telemetry,
          device: body.device || state.telemetry?.device || "unknown",
          temp_c: body.temp_c ?? state.telemetry?.temp_c ?? null,
          wifi_rssi: body.wifi_rssi ?? state.telemetry?.wifi_rssi ?? null,
          heap_free: body.heap_free ?? state.telemetry?.heap_free ?? null,
          heap_total: body.heap_total ?? state.telemetry?.heap_total ?? null,
          ip: body.ip || state.telemetry?.ip || null,
          seenAt: nowIso()
        };
      }
      state.lastSeenAt = nowIso();
      refreshDerivedPages();
      sendJson(res, 200, { ok: true, page: currentPage(), serverTimeMs: Date.now() });
    } catch (err) {
      sendJson(res, 400, { ok: false, error: err.message });
    }
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/telemetry") {
    try {
      const body = await readJsonBody(req);
      console.log("[telemetry]", body.device || "unknown", `fw=${body.fw || state.device?.fw || "unknown"}`, `status=${body.status || "n/a"}`, `temp=${body.temp_c}`, `rssi=${body.wifi_rssi}`);
      state.telemetry = {
        ...state.telemetry,
        ...body,
        seenAt: nowIso()
      };
      if (!state.device) {
        state.device = {
          device: body.device || "unknown",
          fw: body.fw || "unknown",
          screen: body.screen || null,
          ip: body.ip || null,
          mac: body.mac || null,
          connectedAt: nowIso()
        };
      }
      state.lastSeenAt = nowIso();
      refreshDerivedPages();
      sendJson(res, 200, { ok: true, telemetry: state.telemetry, serverTimeMs: Date.now() });
    } catch (err) {
      sendJson(res, 400, { ok: false, error: err.message });
    }
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/swipe") {
    try {
      const body = await readJsonBody(req);
      console.log("[swipe]", body.device || "unknown", body.dir || "next");
      const dir = body.dir || "next";
      const page = applySwipe(dir);
      state.lastSeenAt = nowIso();
      sendJson(res, 200, { ok: true, page });
    } catch (err) {
      sendJson(res, 400, { ok: false, error: err.message });
    }
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/control") {
    try {
      const body = await readJsonBody(req);
      console.log("[control]", body.type || "unknown");
      state.lastControl = {
        ...body,
        at: nowIso()
      };
      if (body.variable && Object.prototype.hasOwnProperty.call(state.variables, body.variable)) {
        state.variables[body.variable] = body.value;
      } else if (body.controlId) {
        const page = currentPage();
        const control = (page.controls || []).find((item) => item.id === body.controlId);
        if (control && control.variable) {
          state.variables[control.variable] = body.value;
        }
      }
      if (body.webhook && typeof body.webhook === "string") {
        let webhookUrl = body.webhook;
        try {
          if (webhookUrl.startsWith("/")) {
            webhookUrl = new URL(webhookUrl, `http://${req.headers.host || "localhost"}`).toString();
          }
          fetch(webhookUrl, {
            method: body.method || "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body)
          }).then(() => {
            state.lastWebhook = { ...body, at: nowIso(), target: webhookUrl };
          }).catch((err) => console.warn(`[webhook] ${err.message}`));
        } catch (err) {
          console.warn(`[webhook] ${err.message}`);
        }
      }
      state.lastSeenAt = nowIso();
      sendJson(res, 200, { ok: true, lastControl: state.lastControl });
    } catch (err) {
      sendJson(res, 400, { ok: false, error: err.message });
    }
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/page") {
    try {
      const body = await readJsonBody(req);
      const page = applyPageUpdate(body.page);
      state.lastSeenAt = nowIso();
      broadcastDisplayUpdate();
      sendJson(res, 200, { ok: true, page });
    } catch (err) {
      sendJson(res, 400, { ok: false, error: err.message });
    }
    return;
  }

  const requestPath = url.pathname === "/" ? "/index.html" : url.pathname;
  const filePath = safePathFromUrl(requestPath);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Not found");
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME_TYPES[ext] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(data);
  });
});

const wss = new WebSocketServer({
  server,
  path: "/ws/display",
  perMessageDeflate: false,
  handleProtocols: (protocols) => (protocols.has("arduino") ? "arduino" : false)
});
wss.on("connection", (socket, req) => {
  console.log(`[ws] client connected from ${req.socket?.remoteAddress || "unknown"}`);
  wsClients.add(socket);
  try {
    socket.send(buildDisplayText());
  } catch (err) {
    console.warn(`[ws] initial send failed: ${err.message}`);
  }
  socket.on("close", () => {
    wsClients.delete(socket);
    console.log("[ws] client disconnected");
  });
  socket.on("error", (err) => {
    wsClients.delete(socket);
    console.warn(`[ws] client error: ${err.message}`);
  });
});

server.listen(PORT, () => {
  console.log(`ESP32-C3 demo server running on http://localhost:${PORT}`);
});

const mdns = publishBonjour();
process.on("exit", () => {
  try {
    mdns?.service?.stop?.();
    mdns?.bonjour?.destroy?.();
  } catch {}
});
