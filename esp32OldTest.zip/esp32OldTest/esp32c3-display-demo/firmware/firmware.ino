/*
  ESP32-C3 generic display demo firmware.

  What it does:
  - connects to Wi-Fi
  - announces itself to the demo server
  - sends telemetry periodically
  - lets you trigger page changes from Serial

  This sketch is intentionally generic. It does not depend on a specific display
  library yet. We can add the actual screen adapter after the hardware choice is fixed.
*/

#include <WiFi.h>
#include <Arduino_GFX_Library.h>
#include <ESPmDNS.h>
#include <Wire.h>
#include <WebSocketsClient.h>
#include <bb_captouch.h>
#include "FreeSansBold10pt7b.h"
#include "FreeMono8pt7b.h"

static const char* WIFI_SSID = "Clio";
static const char* WIFI_PASS = "94Clio7578";
static const char* SERVER_URL = "";
static const char* SERVER_MDNS_TYPE = "espanel";
static const char* SERVER_MDNS_PROTO = "tcp";
static const char* SERVER_MDNS_HINT = "demo";
static const char* DEVICE_NAME = "esp32c3-display";
static const char* FW_VERSION = "0.1.42";
struct WifiProfile {
  const char* ssid;
  const char* pass;
};
static const WifiProfile WIFI_PROFILES[] = {
  {"CL07", "22072002"},
  {"Clio", "94Clio7578"},
};
static const int WIFI_PROFILE_COUNT = sizeof(WIFI_PROFILES) / sizeof(WIFI_PROFILES[0]);

static const int TFT_SCLK = 6;
static const int TFT_MOSI = 7;
static const int TFT_DC = 2;
static const int TFT_CS = 10;
static const int TFT_BL = 3;
static const int TOUCH_I2C_SDA = 4;
static const int TOUCH_I2C_SCL = 5;
static const int TOUCH_INT_PIN = 0;
static const int TOUCH_RST_PIN = 1;
static const uint8_t TOUCH_I2C_ADDR = 0x15;

static const unsigned long TELEMETRY_PERIOD_MS = 5000;
static const unsigned long WIFI_RETRY_MS = 12000;
static const unsigned long WIFI_LOST_GRACE_MS = 30000;
static const unsigned long DISPLAY_REFRESH_MS = 2500;
static const int OPTIONAL_NEXT_BUTTON_PIN = -1;
static bool debugVerbose = true;
static const unsigned long EVENTS_RETRY_MS = 2000;
static const int MAX_DISCOVERY_SERVICES = 4;
static const unsigned long DISCOVERY_SCAN_EMPTY_PERIOD_MS = 5000;
static const unsigned long DISCOVERY_SCAN_LIST_PERIOD_MS = 15000;
static const uint32_t MDNS_SCAN_TIMEOUT_MS = 700;
static const unsigned long DISCOVERY_TAP_COOLDOWN_MS = 160;
static const unsigned long DISCOVERY_TAP_FLASH_MS = 90;
static const unsigned long DISCOVERY_TAP_RESTORE_MS = 80;
static const bool DISCOVERY_TOUCH_DIAG_ONLY = true;

enum DisplayUiMode {
  DISPLAY_UI_WAITING,
  DISPLAY_UI_REMOTE,
  DISPLAY_UI_DISCOVERY,
  DISPLAY_UI_CONNECTING
};

struct DiscoveryService {
  String name;
  String host;
  String ip;
  uint16_t port = 0;
  bool selected = false;
};

struct TouchTarget {
  int16_t x = 0;
  int16_t y = 0;
  int16_t w = 0;
  int16_t h = 0;
};

unsigned long lastTelemetryAt = 0;
unsigned long lastWifiRetryAt = 0;
unsigned long lastButtonSampleAt = 0;
unsigned long lastDiscoveryScanAt = 0;
wl_status_t lastLoggedWifiStatus = WL_IDLE_STATUS;
String lastLoggedWifiIp = "";
String lastLoggedStatusLine = "";
bool lastButtonPressed = false;
bool helloSent = false;
bool wifiConnectInFlight = false;
unsigned long lastHelloAt = 0;
int activeWifiProfileIndex = -1;
int lastGoodWifiProfileIndex = -1;
int lastGoodWifiRetryCount = 0;
bool wifiWasConnected = false;
unsigned long wifiLostSince = 0;
bool touchReady = false;
bool touchWasActive = false;
bool touchSwipeSent = false;
bool touchProbeWasActive = false;
unsigned long lastDiscoveryTouchAt = 0;
uint32_t discoveryTapDebugCount = 0;
uint16_t discoveryTapDebugX = 0;
uint16_t discoveryTapDebugY = 0;
bool discoveryTapRestorePending = false;
unsigned long discoveryTapRestoreAt = 0;
bool discoveryFlashActive = false;
unsigned long discoveryFlashUntil = 0;
uint16_t touchDownX = 0;
uint16_t touchDownY = 0;
BBCapTouch touch;

String deviceIp = "";
Arduino_GFX *gfx = nullptr;
String lastScreenRender;
unsigned long lastDisplayRefreshAt = 0;
float lastTempC = NAN;
long lastWifiRssi = 0;
String serverStatusLine = "SRV --";
String serverStatusDetail = "--";
String serverDisplayLabel = "";
String preferredServerName = "";
String preferredServerHost = "";
uint16_t preferredServerPort = 0;
char serverHost[64] = {0};
uint16_t serverPort = 3131;
unsigned long lastDisplayFetchAt = 0;
static const unsigned long DISPLAY_FETCH_PERIOD_MS = 250;
static const unsigned long HELLO_RETRY_MS = 10000;
bool mdnsReady = false;
unsigned long serverClockOffsetMs = 0;
bool serverClockSynced = false;
unsigned long remotePageRevisionMs = 0;
unsigned long lastSeenPageRevisionMs = 0;
WebSocketsClient eventsClient;
bool displaySocketStarted = false;
String displaySocketTargetKey;
bool suppressSocketDisconnect = false;
bool displaySocketHasPage = false;
DisplayUiMode displayUiMode = DISPLAY_UI_WAITING;
bool discoveryDirty = true;
bool discoveryScanPending = false;
bool discoveryScanInProgress = false;
DiscoveryService discoveryServices[MAX_DISCOVERY_SERVICES];
int discoveryServiceCount = 0;
TouchTarget discoveryTouchTargets[MAX_DISCOVERY_SERVICES];
String remoteDisplayTitle;
String remoteDisplaySubtitle;
String remoteDisplayLine1;
String remoteDisplayLine2;
String remoteDisplayLine3;

void sendSwipe(const char* dir);
void clearDiscoveredServerTarget();
void refreshDisplay(bool force = false);
void showStatusScreen(const char *title, const char *line1, const char *line2, const char *line3, const char *footer);
bool connectDisplayEvents();
void processDisplayEvents();
void onDisplaySocketEvent(WStype_t type, uint8_t * payload, size_t length);
void enterDiscoveryMode(const char* reason);
void clearDiscoveryServices();
int scanBonjourServices(bool force = false);
void selectDiscoveryService(int index);
bool handleDiscoveryTouch();
void drawDiscoveryScreen();
String fitTextToWidth(const String& text, int16_t maxWidth, uint8_t size);
String jsonStringField(const char* key, const String& value, bool last);
String jsonIntField(const char* key, long value, bool last);
String jsonNumberField(const char* key, double value, bool last);
int postJson(const String& endpoint, const String& payload, String* responseBody);
bool isDemoBonjourService(const String& name, const String& host, const String& ip);

struct DisplayLineParts {
  String kind;
  String label;
  String value;
  uint8_t textSize = 1;
};

void logNetState(const char* stage) {
  if (!debugVerbose) return;
  Serial.print("[net] ");
  Serial.print(stage);
  Serial.print(" target=");
  Serial.print(serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost));
  Serial.print(":");
  Serial.print(serverPort);
  Serial.print(" ip=");
  Serial.print(serverHost);
  Serial.print(" pref=");
  if (preferredServerName.length() > 0) {
    Serial.print(preferredServerName);
  } else {
    Serial.print("-");
  }
  Serial.print(" url=");
  if (preferredServerHost.length() > 0) {
    Serial.print(preferredServerHost);
    if (preferredServerPort > 0) {
      Serial.print(":");
      Serial.print(preferredServerPort);
    }
  } else {
    Serial.print("-");
  }
  Serial.println();
}

unsigned long parseUnsignedField(const String& body, const char* key) {
  const String needle = String("\"") + key + "\":";
  const int pos = body.indexOf(needle);
  if (pos < 0) return 0;
  int start = pos + needle.length();
  while (start < (int)body.length() && (body[start] == ' ' || body[start] == '"')) start++;
  int end = start;
  while (end < (int)body.length() && isDigit(body[end])) end++;
  return body.substring(start, end).toInt();
}

void clearDiscoveredServerTarget() {
  if (preferredServerName.length() > 0 || preferredServerHost.length() > 0) {
    return;
  }
  if (displaySocketStarted) {
    eventsClient.disconnect();
  }
  displaySocketStarted = false;
  displaySocketTargetKey = "";
  serverHost[0] = '\0';
  serverPort = 0;
  serverDisplayLabel = "";
}

void clearDiscoveryServices() {
  discoveryServiceCount = 0;
  for (int i = 0; i < MAX_DISCOVERY_SERVICES; ++i) {
    discoveryServices[i] = DiscoveryService();
    discoveryTouchTargets[i] = TouchTarget();
  }
}

void enterDiscoveryMode(const char* reason) {
  Serial.print("[ui] discovery reason=");
  Serial.println(reason ? reason : "-");
  displayUiMode = DISPLAY_UI_DISCOVERY;
  discoveryDirty = true;
  helloSent = false;
  touchWasActive = false;
  touchSwipeSent = false;
  touchDownX = 0;
  touchDownY = 0;
  clearRemoteDisplay();
  displaySocketStarted = false;
  displaySocketTargetKey = "";
  displaySocketHasPage = false;
  lastScreenRender = "";
}

static String discoveryLabelFor(const String& name, const String& host, const String& ip, uint16_t port) {
  String label = name;
  if (label.length() == 0) label = host;
  if (label.length() == 0) label = ip;
  if (label.length() == 0) label = "Bonjour";
  String suffix = ip.length() > 0 ? ip : host;
  if (port > 0) {
    suffix += ":";
    suffix += String(port);
  }
  if (suffix.length() > 0) {
    label += " ";
    label += suffix;
  }
  return label;
}

String discoveryConnectHost(const DiscoveryService& service) {
  if (service.ip.length() > 0 && service.ip != "0.0.0.0") return service.ip;
  return service.host;
}

String mdnsResultAddress(mdns_result_t* result) {
  if (!result) return "";
  mdns_ip_addr_t* addr = result->addr;
  while (addr) {
    if (addr->addr.type == MDNS_IP_PROTOCOL_V4) {
      return IPAddress(addr->addr.u_addr.ip4.addr).toString();
    }
    addr = addr->next;
  }
  return "";
}

String mdnsResultTxt(mdns_result_t* result, const char* key) {
  if (!result || !key) return "";
  for (size_t i = 0; i < result->txt_count; ++i) {
    if (!result->txt[i].key || strcmp(result->txt[i].key, key) != 0) continue;
    if (!result->txt[i].value) return "";
    String value = String(result->txt[i].value);
    if (result->txt_value_len) {
      value = value.substring(0, result->txt_value_len[i]);
    }
    value.trim();
    return value;
  }
  return "";
}

String mdnsQueryName(const char* value) {
  if (!value || value[0] == '\0') return "";
  String out = value;
  if (!out.startsWith("_")) out = "_" + out;
  return out;
}

void sortDiscoveryServices() {
  for (int i = 0; i < discoveryServiceCount - 1; ++i) {
    for (int j = i + 1; j < discoveryServiceCount; ++j) {
      bool shouldSwap = discoveryServices[j].port < discoveryServices[i].port;
      if (!shouldSwap && discoveryServices[j].port == discoveryServices[i].port) {
        shouldSwap = discoveryServices[j].name.compareTo(discoveryServices[i].name) < 0;
      }
      if (shouldSwap) {
        DiscoveryService tmp = discoveryServices[i];
        discoveryServices[i] = discoveryServices[j];
        discoveryServices[j] = tmp;
      }
    }
  }
}

int discoveryIndexFromAxis(uint16_t value) {
  const int16_t buttonH = 38;
  const int16_t gap = 4;
  const int16_t firstY = 50;
  for (int i = 0; i < discoveryServiceCount && i < MAX_DISCOVERY_SERVICES; ++i) {
    const int16_t y = firstY + i * (buttonH + gap);
    const int16_t expandedTop = y - 18;
    const int16_t expandedBottom = y + buttonH + 18;
    if ((int16_t)value >= expandedTop && (int16_t)value <= expandedBottom) {
      return i;
    }
  }
  return -1;
}

bool pointInTarget(uint16_t x, uint16_t y, const TouchTarget& zone, int16_t marginX, int16_t marginY) {
  if (zone.w <= 0 || zone.h <= 0) return false;
  return (int16_t)x >= zone.x - marginX &&
         (int16_t)x <= zone.x + zone.w + marginX &&
         (int16_t)y >= zone.y - marginY &&
         (int16_t)y <= zone.y + zone.h + marginY;
}

int discoveryHitIndex(uint16_t x, uint16_t y) {
  for (int i = 0; i < discoveryServiceCount && i < MAX_DISCOVERY_SERVICES; ++i) {
    if (pointInTarget(x, y, discoveryTouchTargets[i], 6, 8)) return i;
  }
  return -1;
}

bool discoveryServicesMatch(const DiscoveryService previous[], int previousCount) {
  if (previousCount != discoveryServiceCount) return false;
  for (int i = 0; i < discoveryServiceCount; ++i) {
    if (previous[i].name != discoveryServices[i].name) return false;
    if (previous[i].host != discoveryServices[i].host) return false;
    if (previous[i].ip != discoveryServices[i].ip) return false;
    if (previous[i].port != discoveryServices[i].port) return false;
    if (previous[i].selected != discoveryServices[i].selected) return false;
  }
  return true;
}

bool handleDiscoveryTap(uint16_t x, uint16_t y) {
  if (discoveryServiceCount <= 0) {
    const TouchTarget& zone = discoveryTouchTargets[0];
    const bool inButton = zone.w > 0 && zone.h > 0 &&
                          (int16_t)x >= zone.x && (int16_t)x <= zone.x + zone.w &&
                          (int16_t)y >= zone.y && (int16_t)y <= zone.y + zone.h;
    if (inButton) {
      if (debugVerbose && !DISCOVERY_TOUCH_DIAG_ONLY) Serial.println("[discovery] rescan tap");
      discoveryScanPending = true;
      discoveryScanInProgress = true;
      discoveryDirty = true;
      refreshDisplay(true);
      return true;
    }
    return false;
  }

  const int hitIndex = discoveryHitIndex(x, y);
  if (hitIndex < 0) return false;
  if (debugVerbose) {
    Serial.print("[discovery] tap select index=");
    Serial.print(hitIndex);
    Serial.print(" x=");
    Serial.print(x);
    Serial.print(" y=");
    Serial.println(y);
  }
  selectDiscoveryService(hitIndex);
  return true;
}

void flashTouchProbe(uint16_t x, uint16_t y) {
  if (!gfx) return;
  gfx->fillScreen(RGB565_YELLOW);
  drawCenteredText(120, 100, "TAP", RGB565_BLACK, 2);
  String pos = String(x) + "," + String(y);
  drawCenteredText(120, 132, pos.c_str(), RGB565_BLACK, 1);
  delay(700);
  discoveryDirty = true;
  refreshDisplay(true);
}

bool handleGlobalTouchProbe() {
  if (!touchReady) return false;
  TOUCHINFO ti;
  const bool active = touch.getSamples(&ti) && ti.count > 0;
  if (!active) {
    touchProbeWasActive = false;
    return false;
  }
  const uint16_t x = ti.x[0];
  const uint16_t y = ti.y[0];
  if (displayUiMode == DISPLAY_UI_DISCOVERY || displayUiMode == DISPLAY_UI_CONNECTING) {
    if (!touchProbeWasActive) {
      touchProbeWasActive = true;
      Serial.print("[touch-probe] x=");
      Serial.print(x);
      Serial.print(" y=");
      Serial.print(y);
      Serial.print(" mode=");
      Serial.println((int)displayUiMode);
      flashTouchProbe(x, y);
      handleDiscoveryTap(x, y);
    }
    return true;
  }
  if (touchProbeWasActive) {
    return false;
  }
  touchProbeWasActive = true;
  Serial.print("[touch-probe] x=");
  Serial.print(x);
  Serial.print(" y=");
  Serial.print(y);
  Serial.print(" mode=");
  Serial.println((int)displayUiMode);
  flashTouchProbe(x, y);
  return false;
}

int scanBonjourServices(bool force) {
  if (WiFi.status() != WL_CONNECTED) {
    clearDiscoveryServices();
    return 0;
  }
  const unsigned long now = millis();
  const unsigned long scanPeriod = discoveryServiceCount > 0 ? DISCOVERY_SCAN_LIST_PERIOD_MS : DISCOVERY_SCAN_EMPTY_PERIOD_MS;
  if (!force && now - lastDiscoveryScanAt < scanPeriod) {
    return discoveryServiceCount;
  }
  lastDiscoveryScanAt = now;

  if (!mdnsReady) {
    if (!MDNS.begin(DEVICE_NAME)) {
      Serial.println("MDNS begin failed");
      clearDiscoveryServices();
      return 0;
    }
    mdnsReady = true;
  }

  DiscoveryService previous[MAX_DISCOVERY_SERVICES];
  const int previousCount = discoveryServiceCount;
  for (int i = 0; i < MAX_DISCOVERY_SERVICES; ++i) {
    previous[i] = discoveryServices[i];
  }

  const unsigned long queryStart = millis();
  const String serviceType = mdnsQueryName(SERVER_MDNS_TYPE);
  const String proto = mdnsQueryName(SERVER_MDNS_PROTO);
  mdns_result_t* results = nullptr;
  const esp_err_t err = mdns_query_ptr(serviceType.c_str(), proto.c_str(), MDNS_SCAN_TIMEOUT_MS, MAX_DISCOVERY_SERVICES, &results);
  int count = 0;
  for (mdns_result_t* result = results; result; result = result->next) {
    count++;
  }
  if (debugVerbose && !DISCOVERY_TOUCH_DIAG_ONLY) {
    Serial.print("[mdns] discovery services=");
    Serial.println(count);
    Serial.print("[mdns] query elapsed_ms=");
    Serial.print(millis() - queryStart);
    Serial.print(" err=");
    Serial.println((int)err);
  }
  clearDiscoveryServices();
  if (err != ESP_OK || count <= 0 || !results) {
    if (results) mdns_query_results_free(results);
    if (previousCount > 0) discoveryDirty = true;
    return 0;
  }

  for (mdns_result_t* result = results; result && discoveryServiceCount < MAX_DISCOVERY_SERVICES; result = result->next) {
    DiscoveryService service;
    service.name = result->instance_name ? String(result->instance_name) : String("");
    service.host = result->hostname ? String(result->hostname) : String("");
    service.ip = mdnsResultAddress(result);
    String advertisedHost = mdnsResultTxt(result, "host");
    if (advertisedHost.length() > 0) {
      service.ip = advertisedHost;
    }
    service.port = result->port;
    service.selected = false;
    if (!isDemoBonjourService(service.name, service.host, service.ip)) {
      continue;
    }
    if (service.port == 0) {
      continue;
    }
    if (service.name.length() == 0 && service.host.length() == 0 && service.ip.length() == 0) {
      continue;
    }
    if (discoveryConnectHost(service).length() == 0) {
      continue;
    }
    discoveryServices[discoveryServiceCount++] = service;
    if (debugVerbose && !DISCOVERY_TOUCH_DIAG_ONLY) {
      Serial.print("[mdns] choice ");
      Serial.print(discoveryServiceCount - 1);
      Serial.print(" name=");
      Serial.print(service.name);
      Serial.print(" host=");
      Serial.print(service.host);
      Serial.print(" ip=");
      Serial.print(service.ip);
      Serial.print(" port=");
      Serial.println(service.port);
    }
  }
  mdns_query_results_free(results);

  sortDiscoveryServices();

  for (int i = 0; i < discoveryServiceCount; ++i) {
    const String serviceHost = discoveryConnectHost(discoveryServices[i]);
    if (serviceHost.equalsIgnoreCase(preferredServerHost) && (preferredServerPort == 0 || preferredServerPort == discoveryServices[i].port)) {
      discoveryServices[i].selected = true;
    } else if (preferredServerName.length() > 0) {
      const String probe = discoveryServices[i].name.length() > 0 ? discoveryServices[i].name : discoveryServices[i].host;
      if (probe.equalsIgnoreCase(preferredServerName)) {
        discoveryServices[i].selected = true;
      }
    }
  }

  if (!discoveryServicesMatch(previous, previousCount)) {
    discoveryDirty = true;
  }
  return discoveryServiceCount;
}

bool isDemoBonjourService(const String& name, const String& host, const String& ip) {
  String probe = name + " " + host + " " + ip;
  probe.toLowerCase();
  return probe.indexOf("demo") >= 0 || probe.indexOf("display") >= 0 || probe.indexOf("esp32") >= 0 || probe.indexOf("raspisynth") >= 0;
}

void selectDiscoveryService(int index) {
  if (index < 0 || index >= discoveryServiceCount) return;
  const DiscoveryService service = discoveryServices[index];
  String chosenHost = discoveryConnectHost(service);
  if (chosenHost.length() == 0) return;

  preferredServerName = service.name;
  preferredServerHost = chosenHost;
  preferredServerPort = service.port;
  strlcpy(serverHost, chosenHost.c_str(), sizeof(serverHost));
  serverPort = service.port;
  serverDisplayLabel = service.name.length() > 0 ? service.name : chosenHost;
  displayUiMode = DISPLAY_UI_CONNECTING;
  Serial.print("[ui] connecting target=");
  Serial.print(chosenHost);
  Serial.print(":");
  Serial.println(service.port);
  suppressSocketDisconnect = true;
  eventsClient.disconnect();
  displaySocketStarted = false;
  displaySocketTargetKey = "";
  displaySocketHasPage = false;
  discoveryDirty = true;
  helloSent = false;
  lastHelloAt = 0;
  serverClockSynced = false;
  serverClockOffsetMs = 0;
  remotePageRevisionMs = 0;
  lastSeenPageRevisionMs = 0;
  for (int i = 0; i < discoveryServiceCount; ++i) {
    discoveryServices[i].selected = (i == index);
  }
  Serial.print("[discovery] selected ");
  Serial.print(serverDisplayLabel);
  Serial.print(" @ ");
  Serial.print(serverHost);
  Serial.print(":");
  Serial.println(serverPort);
  refreshDisplay(true);
  if (WiFi.status() == WL_CONNECTED) {
    connectDisplayEvents();
    processDisplayEvents();
  }
}

bool handleDiscoveryTouch() {
  if (!touchReady) return false;
  TOUCHINFO ti;
  const bool active = touch.getSamples(&ti) && ti.count > 0;
  if (!active) {
    touchWasActive = false;
    touchSwipeSent = false;
    return false;
  }

  const uint16_t x = ti.x[0];
  const uint16_t y = ti.y[0];
  const unsigned long now = millis();
  if (now - lastDiscoveryTouchAt < DISCOVERY_TAP_COOLDOWN_MS) {
    touchWasActive = true;
    return true;
  }

  touchDownX = x;
  touchDownY = y;
  touchSwipeSent = false;
  lastDiscoveryTouchAt = now;
  discoveryTapDebugCount++;
  discoveryTapDebugX = x;
  discoveryTapDebugY = y;
  if (gfx) {
    gfx->fillScreen(RGB565_YELLOW);
    drawCenteredText(120, 118, "TAP", RGB565_BLACK, 2);
    drawCenteredText(120, 148, String(discoveryTapDebugCount), RGB565_BLACK, 1);
    discoveryFlashActive = true;
    discoveryFlashUntil = millis() + DISCOVERY_TAP_FLASH_MS;
    if (DISCOVERY_TOUCH_DIAG_ONLY) {
      discoveryTapRestorePending = true;
      discoveryTapRestoreAt = millis() + DISCOVERY_TAP_RESTORE_MS;
      discoveryDirty = false;
    } else {
      discoveryDirty = true;
      refreshDisplay(true);
    }
  }
  if (debugVerbose && !DISCOVERY_TOUCH_DIAG_ONLY) {
    Serial.print("[discovery] touch x=");
    Serial.print(x);
    Serial.print(" y=");
    Serial.println(y);
  }
  if (DISCOVERY_TOUCH_DIAG_ONLY) {
    const bool rescanTap = discoveryServiceCount <= 0 &&
                           pointInTarget(x, y, discoveryTouchTargets[0], 0, 0);
    if (rescanTap) {
      discoveryFlashActive = false;
      discoveryTapRestorePending = false;
      handleDiscoveryTap(x, y);
    } else {
      discoveryScanPending = false;
      discoveryScanInProgress = false;
    }
    touchWasActive = true;
    return true;
  }
  handleDiscoveryTap(x, y);

  touchWasActive = true;
  return true;
}

DisplayLineParts splitLine(const String& line) {
  DisplayLineParts parts;
  const int firstSep = line.indexOf('|');
  const int secondSep = firstSep >= 0 ? line.indexOf('|', firstSep + 1) : -1;
  if (firstSep >= 0 && secondSep >= 0) {
    parts.kind = line.substring(0, firstSep);
    parts.label = line.substring(firstSep + 1, secondSep);
    parts.value = line.substring(secondSep + 1);
    parts.kind.trim();
    parts.label.trim();
    parts.value.trim();
    if (parts.label.startsWith("size=")) {
      parts.textSize = (uint8_t)parts.label.substring(5).toInt();
      if (parts.textSize == 0) parts.textSize = 1;
      parts.label = "";
    }
  } else {
    const int colon = line.indexOf(':');
    if (colon >= 0) {
      parts.label = line.substring(0, colon);
      parts.value = line.substring(colon + 1);
      parts.label.trim();
      parts.value.trim();
    } else {
      parts.label = line;
      parts.value = "";
    }
  }
  if (parts.kind.length() == 0) {
    if (parts.label.equalsIgnoreCase("Gain") || parts.label.equalsIgnoreCase("Backlight")) {
      parts.kind = "slider";
    } else if (parts.label.equalsIgnoreCase("Mute")) {
      parts.kind = "toggle";
    } else if (parts.label.equalsIgnoreCase("Preset")) {
      parts.kind = "selector";
    } else if (parts.label.equalsIgnoreCase("Wi-Fi") || parts.label.equalsIgnoreCase("Heap") || parts.label.equalsIgnoreCase("Chip temp")) {
      parts.kind = "meter";
    } else {
      parts.kind = "text";
    }
  }
  if (parts.value.length() == 0 && parts.kind == "title") {
    parts.label = parts.kind;
    parts.kind = "text";
  } else {
    parts.kind.trim();
  }
  return parts;
}

void drawCenteredText(int16_t centerX, int16_t y, const String& text, uint16_t color, uint8_t size) {
  if (!gfx || text.length() == 0) return;
  gfx->setFont(&FreeMono8pt7b);
  gfx->setTextColor(color);
  gfx->setTextSize(size);
  int16_t x1 = 0, y1 = 0;
  uint16_t w = 0, h = 0;
  gfx->getTextBounds(text.c_str(), 0, y, &x1, &y1, &w, &h);
  const int16_t x = centerX - (int16_t)w / 2;
  gfx->setCursor(x, y);
  gfx->println(text);
}

void drawRightAlignedText(int16_t rightX, int16_t y, const String& text, uint16_t color, uint8_t size) {
  if (!gfx || text.length() == 0) return;
  gfx->setFont(&FreeMono8pt7b);
  gfx->setTextColor(color);
  gfx->setTextSize(size);
  int16_t x1 = 0, y1 = 0;
  uint16_t w = 0, h = 0;
  gfx->getTextBounds(text.c_str(), 0, y, &x1, &y1, &w, &h);
  const int16_t x = rightX - (int16_t)w;
  gfx->setCursor(x, y);
  gfx->println(text);
}

uint16_t variantColor(const String& variant) {
  if (variant.equalsIgnoreCase("success")) return gfx->color565(54, 118, 80);
  if (variant.equalsIgnoreCase("warning")) return gfx->color565(154, 117, 48);
  if (variant.equalsIgnoreCase("danger")) return gfx->color565(159, 63, 63);
  if (variant.equalsIgnoreCase("secondary")) return gfx->color565(86, 98, 112);
  if (variant.equalsIgnoreCase("light")) return gfx->color565(222, 230, 236);
  return gfx->color565(42, 54, 108);
}

uint16_t buttonTextColor(const String& variant) {
  if (variant.equalsIgnoreCase("light")) return RGB565_BLACK;
  return RGB565_WHITE;
}

void drawButtonPill(int16_t x, int16_t y, int16_t w, int16_t h, const String& text, const String& variant) {
  gfx->fillRoundRect(x, y, w, h, h / 2, variantColor(variant));
  gfx->drawRoundRect(x, y, w, h, h / 2, RGB565_WHITE);
  gfx->setTextColor(buttonTextColor(variant));
  gfx->setTextSize(1);
  int16_t x1 = 0, y1 = 0;
  uint16_t tw = 0, th = 0;
  gfx->getTextBounds(text.c_str(), 0, y + 8, &x1, &y1, &tw, &th);
  gfx->setCursor(x + (w - (int16_t)tw) / 2, y + 8);
  gfx->println(text);
}

void drawValuePill(int16_t x, int16_t y, int16_t w, int16_t h, const String& text, uint16_t fill, uint16_t textColor) {
  gfx->fillRoundRect(x, y, w, h, h / 2, fill);
  gfx->drawRoundRect(x, y, w, h, h / 2, RGB565_WHITE);
  gfx->setTextColor(textColor);
  gfx->setTextSize(1);
  gfx->setCursor(x + 8, y + 8);
  gfx->println(text);
}

void drawPercentBar(int16_t x, int16_t y, int16_t w, int16_t h, int percent) {
  percent = constrain(percent, 0, 100);
  gfx->drawRoundRect(x, y, w, h, h / 2, gfx->color565(120, 132, 144));
  gfx->fillRoundRect(x + 1, y + 1, (w - 2) * percent / 100, h - 2, (h - 2) / 2, gfx->color565(140, 243, 255));
  if (percent > 12) {
    gfx->drawFastVLine(x + 1 + ((w - 2) * percent / 100) - 2, y + 1, h - 2, gfx->color565(185, 245, 200));
  }
}

void drawGraphicalScreen(const String& title, const String& line1, const String& line2, const String& line3, const String& line4) {
  if (!gfx) return;
  gfx->fillScreen(RGB565_BLACK);
  gfx->setTextWrap(false);
  gfx->setFont(&FreeMono8pt7b);

  const int16_t cardX = 15;
  const int16_t cardW = 210;
  const int16_t cardH = 27;
  const int16_t gap = 5;
  const int16_t cardStartY = 55;
  const uint8_t bodyTextSize = 1;
  String header = String(title);
  header.toUpperCase();

  drawCenteredText(120, 37, header, RGB565_WHITE, 2);

  const String lines[4] = {line1, line2, line3, line4};
  int16_t currentY = cardStartY;
  for (int i = 0; i < 4; ++i) {
    if (lines[i].length() == 0) continue;
    const int16_t y = currentY;
    DisplayLineParts parts = splitLine(lines[i]);
    const int16_t renderedCardH = (parts.label.length() == 0 && parts.value.length() > 0 && parts.textSize >= 2)
      ? cardH + 8
      : cardH;
    gfx->fillRoundRect(cardX, y, cardW, renderedCardH, 8, gfx->color565(24, 30, 36));
    gfx->drawRoundRect(cardX, y, cardW, renderedCardH, 8, gfx->color565(118, 128, 138));

    const bool contentOnly = parts.label.length() == 0 && parts.value.length() > 0;
    if (!contentOnly) {
      gfx->setFont(&FreeMono8pt7b);
      gfx->setTextColor(RGB565_WHITE);
      gfx->setTextSize(bodyTextSize);
      gfx->setCursor(cardX + 8, y + 16);
      gfx->println(parts.label);
    }

    if (parts.kind.equalsIgnoreCase("slider") && parts.value.endsWith("%")) {
      const int pct = parts.value.substring(0, parts.value.length() - 1).toInt();
      drawPercentBar(cardX + 84, y + 8, 105, 10, pct);
    } else if (parts.kind.equalsIgnoreCase("slider")) {
      int pct = parts.value.toFloat() * 100.0f;
      if (pct < 0) pct = 0;
      if (pct > 100) pct = 100;
      drawPercentBar(cardX + 84, y + 8, 105, 10, pct);
    } else if (parts.kind.equalsIgnoreCase("toggle")) {
      const bool on = parts.value.equalsIgnoreCase("ON");
      drawValuePill(cardX + 131, y + 6, 60, 15, parts.value, on ? gfx->color565(156, 64, 64) : gfx->color565(54, 82, 164), RGB565_WHITE);
    } else if (parts.kind.equalsIgnoreCase("selector")) {
      drawRightAlignedText(cardX + 197, y + 17, parts.value, RGB565_WHITE, bodyTextSize);
    } else if (parts.kind.equalsIgnoreCase("button")) {
      String variant = "primary";
      if (parts.label.startsWith("variant=")) {
        variant = parts.label.substring(8);
      }
      drawButtonPill(cardX + 8, y + 5, 194, 17, parts.value, variant);
    } else if (parts.kind.equalsIgnoreCase("meter") && parts.value.length() > 0) {
      gfx->setFont(&FreeMono8pt7b);
      gfx->setTextColor(gfx->color565(222, 228, 232));
      gfx->setTextSize(bodyTextSize);
      gfx->setCursor(cardX + 92, y + 17);
      gfx->println(parts.value);
      String unit = "";
      if (parts.value.endsWith("C")) unit = "C";
      if (parts.value.endsWith("dBm")) unit = "dBm";
      if (unit.length() > 0) {
        drawValuePill(cardX + 173, y + 6, 32, 15, unit, gfx->color565(42, 54, 108), RGB565_WHITE);
      }
    } else if (contentOnly) {
      gfx->setFont(&FreeMono8pt7b);
      gfx->setTextColor(RGB565_WHITE);
      gfx->setTextSize(parts.textSize);
      gfx->setCursor(cardX + 8, y + 26);
      gfx->println(parts.value);
    } else if (parts.value.length() > 0) {
      gfx->setFont(&FreeMono8pt7b);
      gfx->setTextColor(RGB565_WHITE);
      gfx->setTextSize(bodyTextSize);
      gfx->setCursor(cardX + 92, y + 17);
      gfx->println(parts.value);
    }
    currentY += renderedCardH + gap;
  }
}

void drawServerChoiceButton(int index, int16_t x, int16_t y, int16_t w, int16_t h, const DiscoveryService& service) {
  const bool selected = service.selected;
  const uint16_t fill = selected ? gfx->color565(56, 120, 78) : gfx->color565(24, 30, 36);
  const uint16_t border = selected ? gfx->color565(194, 255, 210) : gfx->color565(118, 128, 138);
  gfx->fillRoundRect(x, y, w, h, 8, fill);
  gfx->drawRoundRect(x, y, w, h, 8, border);

  String name = service.name.length() > 0 ? service.name : String("Bonjour server");
  String endpoint = discoveryConnectHost(service);
  if (service.port > 0) {
    endpoint += ":";
    endpoint += String(service.port);
  }
  name = fitTextToWidth(name, w - 16, 1);
  endpoint = fitTextToWidth(endpoint, w - 16, 1);

  gfx->setFont(&FreeMono8pt7b);
  gfx->setTextWrap(false);
  gfx->setTextColor(RGB565_WHITE);
  gfx->setTextSize(1);

  int16_t x1 = 0, y1 = 0;
  uint16_t tw = 0, th = 0;
  gfx->getTextBounds(name.c_str(), 0, y + 13, &x1, &y1, &tw, &th);
  gfx->setCursor(x + 8, y + 13);
  gfx->println(name);

  gfx->setFont(&FreeMono8pt7b);
  gfx->setTextColor(selected ? gfx->color565(228, 248, 232) : gfx->color565(210, 220, 228));
  gfx->setTextSize(1);
  gfx->getTextBounds(endpoint.c_str(), 0, y + 27, &x1, &y1, &tw, &th);
  gfx->setCursor(x + 8, y + 27);
  gfx->println(endpoint);

  if (index >= 0 && index < MAX_DISCOVERY_SERVICES) {
    discoveryTouchTargets[index].x = x;
    discoveryTouchTargets[index].y = y;
    discoveryTouchTargets[index].w = w;
    discoveryTouchTargets[index].h = h;
  }
}

void drawDiscoveryScreen() {
  if (!gfx) return;
  gfx->fillScreen(RGB565_BLACK);
  gfx->setTextWrap(false);
  gfx->setFont(&FreeMono8pt7b);

  const int16_t cardX = 14;
  const int16_t cardW = 212;
  const int16_t buttonH = 38;
  const int16_t gap = 4;
  const int16_t firstY = 50;

  const bool connecting = displayUiMode == DISPLAY_UI_CONNECTING;
  drawCenteredText(120, 23, connecting ? "CONNECTING" : "SERVER SEARCH", RGB565_WHITE, 2);
  if (discoveryScanInProgress) {
    drawCenteredText(120, 47, "Scanning Bonjour", gfx->color565(210, 220, 228), 1);
    gfx->fillRoundRect(32, 70, 176, 88, 12, gfx->color565(24, 30, 36));
    gfx->drawRoundRect(32, 70, 176, 88, 12, gfx->color565(118, 128, 138));
    gfx->drawCircle(120, 108, 17, gfx->color565(170, 182, 192));
    gfx->fillCircle(133, 96, 4, gfx->color565(240, 244, 248));
    drawCenteredText(120, 144, "please wait", gfx->color565(210, 220, 228), 1);
    for (int i = 0; i < MAX_DISCOVERY_SERVICES; ++i) {
      discoveryTouchTargets[i] = TouchTarget();
    }
    return;
  }
  if (connecting) {
    String target = serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost);
    if (target.length() == 0) target = "selected server";
    drawCenteredText(120, 39, fitTextToWidth(target, 206, 1), gfx->color565(170, 182, 192), 1);
    gfx->fillRoundRect(cardX, 70, cardW, 74, 10, gfx->color565(24, 30, 36));
    gfx->drawRoundRect(cardX, 70, cardW, 74, 10, gfx->color565(118, 128, 138));
    drawCenteredText(120, 97, fitTextToWidth(String(serverHost) + ":" + String(serverPort), 196, 1), RGB565_WHITE, 1);
    drawCenteredText(120, 122, "Waiting websocket", gfx->color565(210, 220, 228), 1);
    for (int i = 0; i < MAX_DISCOVERY_SERVICES; ++i) {
      discoveryTouchTargets[i] = TouchTarget();
    }
    return;
  } else {
    drawCenteredText(120, 39, "Bonjour scan active", gfx->color565(170, 182, 192), 1);
  }

  if (discoveryServiceCount <= 0) {
    gfx->fillRoundRect(cardX, firstY, cardW, 78, 10, gfx->color565(24, 30, 36));
    gfx->drawRoundRect(cardX, firstY, cardW, 78, 10, gfx->color565(118, 128, 138));
    drawCenteredText(120, firstY + 30, "No Bonjour servers", RGB565_WHITE, 1);
    drawCenteredText(120, firstY + 48, "Waiting for a demo server", gfx->color565(210, 220, 228), 1);
    gfx->fillRoundRect(50, 150, 140, 26, 13, gfx->color565(165, 70, 60));
    gfx->drawRoundRect(50, 150, 140, 26, 13, RGB565_WHITE);
    drawCenteredText(120, 167, "RESCAN", RGB565_WHITE, 1);
    discoveryTouchTargets[0].x = 50;
    discoveryTouchTargets[0].y = 150;
    discoveryTouchTargets[0].w = 140;
    discoveryTouchTargets[0].h = 26;
    for (int i = 1; i < MAX_DISCOVERY_SERVICES; ++i) {
      discoveryTouchTargets[i] = TouchTarget();
    }
    return;
  }

  for (int i = 0; i < discoveryServiceCount && i < MAX_DISCOVERY_SERVICES; ++i) {
    const int16_t y = firstY + i * (buttonH + gap);
    drawServerChoiceButton(i, cardX, y, cardW, buttonH, discoveryServices[i]);
  }

  const int footerY = firstY + discoveryServiceCount * (buttonH + gap) + 8;
  if (footerY < 214) {
    if (!connecting && DISCOVERY_TOUCH_DIAG_ONLY) {
      String diag = "TAPS ";
      diag += String(discoveryTapDebugCount);
      if (discoveryTapDebugCount > 0) {
        diag += " ";
        diag += String(discoveryTapDebugX);
        diag += ",";
        diag += String(discoveryTapDebugY);
      }
      drawCenteredText(120, footerY, fitTextToWidth(diag, 206, 1), gfx->color565(255, 226, 120), 1);
    } else {
      drawCenteredText(120, footerY, connecting ? "Waiting for websocket..." : "Tap a server to connect", gfx->color565(210, 220, 228), 1);
    }
  }
}

String fitTextToWidth(const String& text, int16_t maxWidth, uint8_t size) {
  if (!gfx || text.length() == 0) return text;
  gfx->setFont(&FreeMono8pt7b);
  gfx->setTextSize(size);
  int16_t x1 = 0, y1 = 0;
  uint16_t w = 0, h = 0;
  String out = text;
  gfx->getTextBounds(out.c_str(), 0, 0, &x1, &y1, &w, &h);
  if (w <= (uint16_t)maxWidth) return out;
  while (out.length() > 1) {
    out.remove(out.length() - 1);
    String clipped = out + "...";
    gfx->getTextBounds(clipped.c_str(), 0, 0, &x1, &y1, &w, &h);
    if (w <= (uint16_t)maxWidth) return clipped;
  }
  return String("...");
}

void updateServerStatus(bool ok, const char *suffix) {
  String label = serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost);
  if (label.length() == 0) label = "mdns";
  if (serverPort > 0 && label.indexOf(':') < 0) {
    label += ":";
    label += String(serverPort);
  }
  if (label.length() > 12) {
    label = label.substring(0, 9) + "...";
  }
  if (ok) {
    serverStatusDetail = (suffix && suffix[0] != '\0') ? String(suffix) : String("OK");
    serverStatusLine = String("SRV ") + label + " " + suffix;
  } else {
    const char *state = (suffix && suffix[0] != '\0') ? suffix : "ERR";
    serverStatusDetail = String(state);
    serverStatusLine = String("SRV ") + label + " " + state;
  }
  if (serverStatusLine != lastLoggedStatusLine) {
    lastLoggedStatusLine = serverStatusLine;
    Serial.print("[status] ");
    Serial.println(serverStatusLine);
  }
}

void logWifiStateIfChanged() {
  const wl_status_t status = WiFi.status();
  const String ip = status == WL_CONNECTED ? WiFi.localIP().toString() : String("");
  if (status == WL_CONNECTED && deviceIp != ip) {
    deviceIp = ip;
  }
  if (status == lastLoggedWifiStatus && ip == lastLoggedWifiIp) return;
  lastLoggedWifiStatus = status;
  lastLoggedWifiIp = ip;
  Serial.print("[wifi] status=");
  Serial.print((int)status);
  Serial.print(" ssid=");
  Serial.print(WiFi.SSID());
  Serial.print(" ip=");
  Serial.print(ip.length() > 0 ? ip : String("-"));
  Serial.print(" rssi=");
  Serial.println(status == WL_CONNECTED ? WiFi.RSSI() : 0);
}

void parseServerUrl() {
  String url = SERVER_URL;
  serverDisplayLabel = "";
  preferredServerName = "";
  preferredServerHost = "";
  preferredServerPort = 0;
  serverHost[0] = '\0';
  serverPort = 0;
  if (url.length() == 0) {
    return;
  }
  url.replace("http://", "");
  int slash = url.indexOf('/');
  if (slash >= 0) url = url.substring(0, slash);
  int colon = url.lastIndexOf(':');
  String host = url;
  uint16_t port = 80;
  if (colon >= 0) {
    host = url.substring(0, colon);
    port = (uint16_t)url.substring(colon + 1).toInt();
    if (port == 0) port = 80;
  }
  strlcpy(serverHost, host.c_str(), sizeof(serverHost));
  serverPort = port;
  serverDisplayLabel = host;
  if (serverPort > 0) {
    serverDisplayLabel += ":";
    serverDisplayLabel += String(serverPort);
  }
}

bool resolveServerFromMdns() {
  if (serverHost[0] != '\0' || WiFi.status() != WL_CONNECTED) return serverHost[0] != '\0';
  if (!mdnsReady) {
    if (!MDNS.begin(DEVICE_NAME)) {
      Serial.println("MDNS begin failed");
      return false;
    }
    mdnsReady = true;
  }

  const int count = MDNS.queryService(SERVER_MDNS_TYPE, SERVER_MDNS_PROTO);
  Serial.print("[mdns] services=");
  Serial.println(count);
  if (count <= 0) {
    Serial.println("No matching mDNS panel services found");
    serverStatusLine = "SRV -- MDNS";
    return false;
  }

  int chosen = -1;
  int eligibleCount = 0;
  const bool preferName = preferredServerName.length() > 0;
  const bool preferHost = preferredServerHost.length() > 0;
  for (int i = 0; i < count; ++i) {
    String name = MDNS.instanceName(i);
    String host = MDNS.hostname(i);
    String ipString = MDNS.address(i).toString();
    const uint16_t port = MDNS.port(i);
    Serial.print("[mdns] candidate ");
    Serial.print(i);
    Serial.print(" name=");
    Serial.print(name);
    Serial.print(" host=");
    Serial.print(host);
    Serial.print(" ip=");
    Serial.print(ipString);
    Serial.print(" port=");
    Serial.println(port);
    if (preferName && (name.equalsIgnoreCase(preferredServerName) || host.equalsIgnoreCase(preferredServerName) || ipString.equalsIgnoreCase(preferredServerName))) {
      chosen = i;
      break;
    }
    if (preferHost && (host.equalsIgnoreCase(preferredServerHost) || ipString.equalsIgnoreCase(preferredServerHost))) {
      if (preferredServerPort == 0 || preferredServerPort == port) {
        chosen = i;
        break;
      }
    }
    String probe = name + " " + host;
    probe.toLowerCase();
    if (probe.indexOf(SERVER_MDNS_HINT) >= 0 || probe.indexOf("display") >= 0 || probe.indexOf("demo") >= 0) {
      eligibleCount += 1;
      if (chosen < 0) {
        chosen = i;
      }
    }
  }

  if (chosen < 0 && count == 1) {
    chosen = 0;
    eligibleCount = 1;
    Serial.println("Only one Bonjour HTTP service found; selecting it");
  }

  if (chosen < 0) {
    if (preferHost) {
      IPAddress direct;
      if (direct.fromString(preferredServerHost) && preferredServerPort > 0) {
        strlcpy(serverHost, preferredServerHost.c_str(), sizeof(serverHost));
        serverPort = preferredServerPort;
        serverDisplayLabel = preferredServerName.length() > 0 ? preferredServerName : preferredServerHost;
        Serial.print("[mdns] using direct target ");
        Serial.print(serverHost);
        Serial.print(":");
        Serial.println(serverPort);
        return true;
      }
    }
    Serial.println("No matching Bonjour server preference");
    serverStatusLine = "SRV -- MDNS";
    return false;
  }

  if (!preferName && !preferHost && eligibleCount > 1) {
    Serial.println("Multiple Bonjour services found; manual selection required");
    serverStatusLine = "SRV -- CHOOSE";
    return false;
  }

  String host = MDNS.hostname(chosen);
  String serviceHost = MDNS.instanceName(chosen);
  IPAddress ip = MDNS.address(chosen);
  uint16_t port = MDNS.port(chosen);
  if (port == 0) {
    Serial.println("mDNS service missing address or port");
    serverStatusLine = "SRV -- MDNS";
    return false;
  }

  String ipString = ip.toString();
  String chosenHost = ipString;
  IPAddress hostIp;
  if (host.length() > 0 && hostIp.fromString(host)) {
    chosenHost = host;
  } else if (ip == INADDR_NONE && host.length() > 0) {
    chosenHost = host;
  }
  strlcpy(serverHost, chosenHost.c_str(), sizeof(serverHost));
  serverPort = port;
  serverDisplayLabel = serviceHost.length() > 0 ? serviceHost : MDNS.instanceName(chosen);
  if (serverDisplayLabel.length() == 0) {
    serverDisplayLabel = host;
  }
  if (serverDisplayLabel.length() == 0) {
    serverDisplayLabel = chosenHost;
  }
  Serial.print("mDNS server selected: ");
  Serial.print(serverDisplayLabel);
  Serial.print(" @ ");
  Serial.print(serverHost);
  Serial.print(":");
  Serial.println(serverPort);
  logNetState("mdns-selected");
  return true;
}

bool currentServerMatchesPreference() {
  if (preferredServerName.length() > 0) {
    String currentHost = String(serverHost);
    String probe = serverDisplayLabel.length() > 0 ? serverDisplayLabel : currentHost;
    if (probe.equalsIgnoreCase(preferredServerName) || currentHost.equalsIgnoreCase(preferredServerName)) {
      return true;
    }
  }
  if (preferredServerHost.length() > 0) {
    String currentHost = String(serverHost);
    if (!currentHost.equalsIgnoreCase(preferredServerHost)) {
      return false;
    }
    if (preferredServerPort > 0 && preferredServerPort != serverPort) {
      return false;
    }
    return true;
  }
  return true;
}

bool connectDisplayEvents() {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (displayUiMode == DISPLAY_UI_DISCOVERY) return false;
  if (!ensureServerTarget()) return false;
  const String targetKey = String(serverHost) + ":" + String(serverPort);
  if (displaySocketStarted && displaySocketTargetKey != targetKey) {
    eventsClient.disconnect();
    displaySocketStarted = false;
    displaySocketHasPage = false;
  }
  if (!displaySocketStarted) {
    displaySocketTargetKey = targetKey;
    eventsClient.onEvent(onDisplaySocketEvent);
    eventsClient.begin(serverHost, serverPort, "/ws/display", "arduino");
    eventsClient.setReconnectInterval(1000);
    eventsClient.disableHeartbeat();
    displaySocketStarted = true;
    Serial.print("[ws] begin ");
    Serial.println(targetKey);
  }
  return true;
}

void processDisplayEvents() {
  if (!connectDisplayEvents()) return;
  eventsClient.loop();
}

void onDisplaySocketEvent(WStype_t type, uint8_t * payload, size_t length) {
  switch (type) {
    case WStype_CONNECTED:
      Serial.println("[ws] connected");
      suppressSocketDisconnect = false;
      if (displaySocketHasPage) {
        displayUiMode = DISPLAY_UI_REMOTE;
      } else {
        displayUiMode = DISPLAY_UI_CONNECTING;
      }
      discoveryDirty = true;
      updateServerStatus(true, "WS OK");
      break;
    case WStype_DISCONNECTED:
      Serial.println("[ws] disconnected");
      {
        const bool hadPage = displaySocketHasPage;
      if (suppressSocketDisconnect) {
        suppressSocketDisconnect = false;
        displaySocketStarted = false;
        displaySocketTargetKey = "";
        displaySocketHasPage = false;
        clearRemoteDisplay();
        refreshDisplay(true);
        break;
      }
      displaySocketStarted = false;
      displaySocketTargetKey = "";
      displaySocketHasPage = false;
      clearRemoteDisplay();
      if (displayUiMode == DISPLAY_UI_CONNECTING || !hadPage) {
        updateServerStatus(false, "WS RETRY");
        refreshDisplay(true);
        break;
      }
      enterDiscoveryMode("ws disconnected");
      clearDiscoveredServerTarget();
      updateServerStatus(false, "WS ERR");
      break;
      }
    case WStype_TEXT: {
      String body;
      body.reserve(length + 1);
      for (size_t i = 0; i < length; ++i) {
        body += (char)payload[i];
      }
      if (debugVerbose) {
        Serial.print("[ws] ");
        Serial.println(body);
      }
      setRemoteDisplayFromText(body);
      displaySocketHasPage = remoteDisplayTitle.length() > 0 || remoteDisplaySubtitle.length() > 0 || remoteDisplayLine1.length() > 0;
      if (displaySocketHasPage) {
        Serial.print("[ui] remote page=");
        Serial.println(remoteDisplayTitle.length() > 0 ? remoteDisplayTitle : String("(untitled)"));
        displayUiMode = DISPLAY_UI_REMOTE;
      }
      refreshDisplay(true);
      updateServerStatus(true, "WS OK");
      break;
    }
    case WStype_ERROR:
      Serial.println("[ws] error");
      {
        const bool hadPage = displaySocketHasPage;
      if (suppressSocketDisconnect) {
        suppressSocketDisconnect = false;
        displaySocketStarted = false;
        displaySocketTargetKey = "";
        displaySocketHasPage = false;
        clearRemoteDisplay();
        refreshDisplay(true);
        break;
      }
      displaySocketStarted = false;
      displaySocketTargetKey = "";
      displaySocketHasPage = false;
      clearRemoteDisplay();
      if (displayUiMode == DISPLAY_UI_CONNECTING || !hadPage) {
        updateServerStatus(false, "WS RETRY");
        refreshDisplay(true);
        break;
      }
      enterDiscoveryMode("ws error");
      clearDiscoveredServerTarget();
      updateServerStatus(false, "WS ERR");
      break;
      }
    default:
      break;
  }
}

bool ensureServerTarget() {
  if (serverHost[0] != '\0' && serverPort > 0) return true;
  return resolveServerFromMdns();
}

bool wifiCredentialsReady() {
  for (int i = 0; i < WIFI_PROFILE_COUNT; ++i) {
    if (WIFI_PROFILES[i].ssid && WIFI_PROFILES[i].ssid[0] != '\0' &&
        WIFI_PROFILES[i].pass && WIFI_PROFILES[i].pass[0] != '\0' &&
        String(WIFI_PROFILES[i].ssid) != "YOUR_WIFI_SSID" &&
        String(WIFI_PROFILES[i].pass) != "YOUR_WIFI_PASSWORD") {
      return true;
    }
  }
  return false;
}

bool initTouch() {
  Wire.end();
  int ok = touch.init(TOUCH_I2C_SDA, TOUCH_I2C_SCL, TOUCH_RST_PIN, TOUCH_INT_PIN);
  if (ok != 0) {
    Serial.println("Touch controller not found");
    touchReady = false;
    return false;
  }

  touch.setOrientation(0, 240, 240);
  touchReady = true;
  Serial.print("Touch ready, sensor type=");
  Serial.println(touch.sensorType());
  return true;
}

void handleTouch() {
  if (!touchReady) return;
  TOUCHINFO ti;
  const bool active = touch.getSamples(&ti) && ti.count > 0;

  if (active) {
    const uint16_t x = ti.x[0];
    const uint16_t y = ti.y[0];
    if (!touchWasActive) {
      touchDownX = x;
      touchDownY = y;
      touchSwipeSent = false;
      Serial.print("touch down x=");
      Serial.print(x);
      Serial.print(" y=");
      Serial.println(y);
    } else if (!touchSwipeSent) {
      const int dx = (int)x - (int)touchDownX;
      const int dy = (int)y - (int)touchDownY;
      if (abs(dx) > 55 && abs(dx) > abs(dy) + 15) {
        Serial.print("touch swipe dx=");
        Serial.print(dx);
        Serial.print(" dy=");
        Serial.println(dy);
        sendSwipe(dx < 0 ? "next" : "prev");
        touchSwipeSent = true;
      }
    }
  }

  touchWasActive = active;
  if (!active) {
    touchSwipeSent = false;
  }
}

void showStatusScreen(const char *title, const char *line1, const char *line2 = "", const char *line3 = "", const char *footer = "") {
  String t = title ? String(title) : String("");
  String l1 = line1 ? String(line1) : String("");
  String l2 = line2 ? String(line2) : String("");
  String l3 = line3 ? String(line3) : String("");
  String f = footer ? String(footer) : String("");
  String render = t + "\n" + l1 + "\n" + l2 + "\n" + l3 + "\n" + f;
  if (render == lastScreenRender) return;
  lastScreenRender = render;
  if (debugVerbose) {
    Serial.print("[screen] ");
    Serial.print(t);
    Serial.print(" | ");
    Serial.print(l1);
    Serial.print(" | ");
    Serial.print(l2);
    Serial.print(" | ");
    Serial.print(l3);
    Serial.print(" | ");
    Serial.println(f);
  }
  drawGraphicalScreen(t, l1, l2, l3, f);
}

bool initDisplay() {
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);

  Arduino_DataBus *bus = new Arduino_ESP32SPI(TFT_DC, TFT_CS, TFT_SCLK, TFT_MOSI, GFX_NOT_DEFINED);
  gfx = new Arduino_GC9A01(bus, GFX_NOT_DEFINED, 0, true);

  if (!gfx->begin()) {
    Serial.println("Display begin failed");
    return false;
  }

  gfx->setRotation(0);
  gfx->fillScreen(RGB565_RED);
  delay(200);
  gfx->fillScreen(RGB565_GREEN);
  delay(200);
  gfx->fillScreen(RGB565_BLUE);
  delay(200);
  showStatusScreen("BOOT", "ESP32-C3 display ready", "boot sequence ok", "", FW_VERSION);
  return true;
}

float readChipTemperatureC() {
#if defined(ARDUINO_ARCH_ESP32)
  return temperatureRead();
#else
  return NAN;
#endif
}

String jsonEscape(const String& s) {
  String out;
  out.reserve(s.length() + 8);
  for (size_t i = 0; i < s.length(); ++i) {
    const char c = s[i];
    switch (c) {
      case '\\': out += "\\\\"; break;
      case '"': out += "\\\""; break;
      case '\n': out += "\\n"; break;
      case '\r': out += "\\r"; break;
      case '\t': out += "\\t"; break;
      default: out += c; break;
    }
  }
  return out;
}

String jsonStringField(const char* key, const String& value, bool last = false) {
  String out = "\"";
  out += key;
  out += "\":\"";
  out += jsonEscape(value);
  out += "\"";
  if (!last) out += ",";
  return out;
}

String jsonNumberField(const char* key, double value, bool last = false) {
  String out = "\"";
  out += key;
  out += "\":";
  if (isnan(value)) {
    out += "null";
  } else {
    out += String(value, 3);
  }
  if (!last) out += ",";
  return out;
}

String jsonIntField(const char* key, long value, bool last = false) {
  String out = "\"";
  out += key;
  out += "\":";
  out += String(value);
  if (!last) out += ",";
  return out;
}

String makeHelloPayload() {
  String ip = WiFi.isConnected() ? WiFi.localIP().toString() : String("");
  const float tempC = readChipTemperatureC();
  const long heapFree = ESP.getFreeHeap();
  const long heapTotal = ESP.getHeapSize();
  const long rssi = WiFi.isConnected() ? WiFi.RSSI() : 0;
  String payload = "{";
  payload += jsonStringField("type", "hello");
  payload += jsonStringField("device", DEVICE_NAME);
  payload += jsonStringField("fw", FW_VERSION);
  payload += jsonStringField("ip", ip);
  payload += jsonNumberField("temp_c", tempC);
  payload += jsonIntField("wifi_rssi", rssi);
  payload += jsonIntField("heap_free", heapFree);
  payload += jsonIntField("heap_total", heapTotal);
  payload += String("\"screen\":{\"w\":240,\"h\":240,\"touch\":") + (touchReady ? "true" : "false") + "}";
  payload += "}";
  return payload;
}

String makeTelemetryPayload() {
  const float tempC = readChipTemperatureC();
  const long heapFree = ESP.getFreeHeap();
  const long heapTotal = ESP.getHeapSize();
  const long rssi = WiFi.isConnected() ? WiFi.RSSI() : 0;

  String payload = "{";
  payload += jsonStringField("type", "telemetry");
  payload += jsonStringField("device", DEVICE_NAME);
  payload += jsonStringField("fw", FW_VERSION);
  payload += jsonStringField("status", serverStatusLine);
  payload += jsonIntField("uptime_ms", millis());
  payload += jsonNumberField("temp_c", tempC);
  payload += jsonIntField("wifi_rssi", rssi);
  payload += jsonIntField("heap_free", heapFree);
  payload += jsonIntField("heap_total", heapTotal);
  payload += jsonStringField("ip", WiFi.isConnected() ? WiFi.localIP().toString() : String(""));
  payload += jsonStringField("ssid", WiFi.isConnected() ? WiFi.SSID() : String(""), true);
  payload += "}";
  return payload;
}

int postJson(const String& endpoint, const String& payload, String* responseBody = nullptr) {
  if (!ensureServerTarget()) {
    Serial.println("No server target available");
    serverStatusLine = "SRV -- MDNS";
    return -1;
  }
  logNetState(("post " + endpoint).c_str());
  WiFiClient client;
  if (!client.connect(serverHost, serverPort)) {
    Serial.println("TCP connect failed");
    serverStatusLine = "SRV " + (serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost)) + " TCP";
    logNetState("tcp-fail");
    clearDiscoveredServerTarget();
    return -1;
  }
  client.print("POST ");
  client.print(endpoint);
  client.println(" HTTP/1.1");
  client.print("Host: ");
  client.println(serverHost);
  client.println("Connection: close");
  client.println("Content-Type: application/json");
  client.print("Content-Length: ");
  client.println(payload.length());
  client.println();
  client.print(payload);

  int status = -1;
  bool headersDone = false;
  if (responseBody) responseBody->remove(0);
  unsigned long start = millis();
  while (millis() - start < 2000) {
    if (!client.available()) {
      if (!client.connected()) break;
      delay(1);
      continue;
    }

    String line = client.readStringUntil('\n');
    line.trim();
    if (line.startsWith("HTTP/")) {
      int sp = line.indexOf(' ');
      if (sp >= 0) {
        status = line.substring(sp + 1, sp + 4).toInt();
      }
    } else if (line.length() == 0) {
      headersDone = true;
    } else if (headersDone && responseBody) {
      *responseBody += line;
      *responseBody += '\n';
    }
  }

  client.stop();
  if (responseBody && responseBody->endsWith("\n")) responseBody->remove(responseBody->length() - 1);
  if (debugVerbose) {
    Serial.print("HTTP ");
    Serial.print(status);
    Serial.print(" ");
    Serial.println(endpoint);
  }
  return status;
}

bool getText(const String& endpoint, String& body, int& status) {
  if (!ensureServerTarget()) {
    Serial.println("No server target available");
    status = -1;
    serverStatusLine = "SRV -- MDNS";
    return false;
  }
  logNetState(("get " + endpoint).c_str());
  WiFiClient client;
  if (!client.connect(serverHost, serverPort)) {
    Serial.println("TCP connect failed");
    status = -1;
    serverStatusLine = "SRV " + (serverDisplayLabel.length() > 0 ? serverDisplayLabel : String(serverHost)) + " TCP";
    logNetState("tcp-fail");
    clearDiscoveredServerTarget();
    return false;
  }

  client.print("GET ");
  client.print(endpoint);
  client.println(" HTTP/1.1");
  client.print("Host: ");
  client.println(serverHost);
  client.println("Connection: close");
  client.println();

  status = -1;
  bool headersDone = false;
  body = "";
  unsigned long start = millis();
  while (millis() - start < 2500) {
    if (!client.available()) {
      if (!client.connected()) break;
      delay(1);
      continue;
    }

    String line = client.readStringUntil('\n');
    line.trim();
    if (!headersDone) {
      if (line.startsWith("HTTP/")) {
        int sp = line.indexOf(' ');
        if (sp >= 0) {
          status = line.substring(sp + 1, sp + 4).toInt();
        }
      } else if (line.length() == 0) {
        headersDone = true;
      }
      continue;
    }

    if (line.length() > 0) {
      body += line;
      body += '\n';
    }
  }

  client.stop();
  if (body.endsWith("\n")) body.remove(body.length() - 1);
  if (debugVerbose) {
    Serial.print("HTTP ");
    Serial.print(status);
    Serial.print(" ");
    Serial.println(endpoint);
  }
  return status >= 200 && status < 300;
}

void clearRemoteDisplay() {
  remoteDisplayTitle = "";
  remoteDisplaySubtitle = "";
  remoteDisplayLine1 = "";
  remoteDisplayLine2 = "";
  remoteDisplayLine3 = "";
}

void setRemoteDisplayFromText(const String& body) {
  clearRemoteDisplay();
  int start = 0;
  String fallback[5];
  int fallbackCount = 0;

  while (start <= body.length()) {
    int nl = body.indexOf('\n', start);
    String part = nl >= 0 ? body.substring(start, nl) : body.substring(start);
    part.trim();

    if (part.startsWith("title=")) {
      remoteDisplayTitle = part.substring(6);
      remoteDisplayTitle.trim();
    } else if (part.startsWith("pagever=")) {
      remotePageRevisionMs = (unsigned long)part.substring(8).toInt();
    } else if (part.startsWith("serverpref=")) {
      String pref = part.substring(11);
      pref.trim();
      preferredServerName = pref;
      Serial.print("preferred server name=");
      Serial.println(preferredServerName);
    } else if (part.startsWith("serverurl=")) {
      String target = part.substring(10);
      target.trim();
      int colon = target.lastIndexOf(':');
      preferredServerHost = target;
      preferredServerPort = 0;
      if (colon >= 0) {
        preferredServerHost = target.substring(0, colon);
        preferredServerPort = (uint16_t)target.substring(colon + 1).toInt();
      }
      Serial.print("preferred server url=");
      Serial.println(target);
    } else if (part.startsWith("line1=")) {
      remoteDisplaySubtitle = part.substring(6);
      remoteDisplaySubtitle.trim();
    } else if (part.startsWith("line2=")) {
      remoteDisplayLine1 = part.substring(6);
      remoteDisplayLine1.trim();
    } else if (part.startsWith("line3=")) {
      remoteDisplayLine2 = part.substring(6);
      remoteDisplayLine2.trim();
    } else if (part.startsWith("line4=")) {
      remoteDisplayLine3 = part.substring(6);
      remoteDisplayLine3.trim();
    } else if (part.length() > 0 && fallbackCount < 5) {
      fallback[fallbackCount++] = part;
    }

    if (nl < 0) break;
    start = nl + 1;
  }

  if (remoteDisplayTitle.length() == 0 && fallbackCount > 0) remoteDisplayTitle = fallback[0];
  if (remoteDisplaySubtitle.length() == 0 && fallbackCount > 1) remoteDisplaySubtitle = fallback[1];
  if (remoteDisplayLine1.length() == 0 && fallbackCount > 2) remoteDisplayLine1 = fallback[2];
  if (remoteDisplayLine2.length() == 0 && fallbackCount > 3) remoteDisplayLine2 = fallback[3];
  if (remoteDisplayLine3.length() == 0 && fallbackCount > 4) remoteDisplayLine3 = fallback[4];
}

void fetchRemoteDisplay() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!ensureServerTarget()) return;
  if (millis() - lastDisplayFetchAt < DISPLAY_FETCH_PERIOD_MS) return;
  lastDisplayFetchAt = millis();

  String body;
  int status = -1;
  if (getText("/api/display.txt", body, status)) {
    if (debugVerbose) {
      Serial.print("[display] ");
      Serial.println(body);
    }
    setRemoteDisplayFromText(body);
    if (remoteDisplayTitle.length() > 0 || remoteDisplaySubtitle.length() > 0 || remoteDisplayLine1.length() > 0) {
      displayUiMode = DISPLAY_UI_REMOTE;
    }
    if (remotePageRevisionMs > 0 && remotePageRevisionMs != lastSeenPageRevisionMs) {
      lastSeenPageRevisionMs = remotePageRevisionMs;
      unsigned long nowServerMs = serverClockSynced ? (serverClockOffsetMs + millis()) : 0;
      if (serverClockSynced && nowServerMs >= remotePageRevisionMs) {
        Serial.print("[page] rev=");
        Serial.print(remotePageRevisionMs);
        Serial.print(" latency_ms=");
        Serial.println(nowServerMs - remotePageRevisionMs);
      } else {
        Serial.print("[page] rev=");
        Serial.println(remotePageRevisionMs);
      }
      refreshDisplay(true);
    }
    if (!currentServerMatchesPreference()) {
      Serial.println("Switching to preferred Bonjour server");
      serverHost[0] = '\0';
      serverPort = 0;
      serverDisplayLabel = "";
      resolveServerFromMdns();
    }
    updateServerStatus(true, "DISPLAY OK");
  } else if (status >= 0) {
    updateServerStatus(false, "DISPLAY ERR");
  }
}

void connectWifi() {
  if (!wifiCredentialsReady()) return;
  if (WiFi.status() == WL_CONNECTED) {
    wifiConnectInFlight = false;
    wifiWasConnected = true;
    wifiLostSince = 0;
    String ssid = WiFi.SSID();
    for (int i = 0; i < WIFI_PROFILE_COUNT; ++i) {
      if (ssid == WIFI_PROFILES[i].ssid) {
        if (lastGoodWifiProfileIndex != i) {
          Serial.print("[wifi] last good profile=");
          Serial.println(WIFI_PROFILES[i].ssid);
        }
        lastGoodWifiProfileIndex = i;
        activeWifiProfileIndex = i;
        lastGoodWifiRetryCount = 0;
        break;
      }
    }
    return;
  }

  const unsigned long now = millis();
  if (wifiWasConnected) {
    if (wifiLostSince == 0) {
      wifiLostSince = now;
      Serial.println("[wifi] transient loss, waiting before reconnect");
    }
    if (now - wifiLostSince < WIFI_LOST_GRACE_MS) {
      return;
    }
  }
  if (wifiConnectInFlight && now - lastWifiRetryAt < WIFI_RETRY_MS) return;
  if (now - lastWifiRetryAt < WIFI_RETRY_MS) return;

  lastWifiRetryAt = millis();
  wifiConnectInFlight = true;
  if (lastGoodWifiProfileIndex >= 0 && lastGoodWifiRetryCount < 3) {
    activeWifiProfileIndex = lastGoodWifiProfileIndex;
    lastGoodWifiRetryCount++;
  } else {
    activeWifiProfileIndex = (activeWifiProfileIndex + 1) % WIFI_PROFILE_COUNT;
    if (activeWifiProfileIndex == lastGoodWifiProfileIndex) {
      lastGoodWifiRetryCount = 1;
    }
  }
  const WifiProfile& profile = WIFI_PROFILES[activeWifiProfileIndex];
  Serial.print("Wi-Fi connecting to ");
  Serial.println(profile.ssid);
  WiFi.disconnect(false, false);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(profile.ssid, profile.pass);
}

void announceIfReady() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!ensureServerTarget()) return;
  const unsigned long now = millis();
  if (helloSent && now - lastHelloAt < HELLO_RETRY_MS) return;
  if (debugVerbose) Serial.println("[hello] sending");
  deviceIp = WiFi.localIP().toString();
  String response;
  const unsigned long sentAt = millis();
  const int code = postJson("/api/hello", makeHelloPayload(), &response);
  if (code >= 200 && code < 300) {
    const unsigned long serverTimeMs = parseUnsignedField(response, "serverTimeMs");
    if (serverTimeMs > 0 && sentAt > 0) {
      serverClockOffsetMs = serverTimeMs - sentAt;
      serverClockSynced = true;
    }
    updateServerStatus(true, "HELLO OK");
    refreshDisplay(true);
    helloSent = true;
    lastHelloAt = now;
  } else {
    updateServerStatus(false, "HELLO ERR");
    refreshDisplay(true);
  }
}

void sendTelemetry() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!ensureServerTarget()) return;
  if (debugVerbose) Serial.println("[telemetry] sending");
  const String payload = makeTelemetryPayload();
  if (debugVerbose) {
    Serial.print("[telemetry] payload ");
    Serial.println(payload);
  }
  const int code = postJson("/api/telemetry", payload);
  Serial.print("[telemetry] http=");
  Serial.println(code);
  if (code >= 200 && code < 300) {
    updateServerStatus(true, "TEL OK");
    refreshDisplay(true);
    if (!helloSent) {
      helloSent = true;
      lastHelloAt = millis();
    }
  } else {
    updateServerStatus(false, "TEL ERR");
    if (displayUiMode == DISPLAY_UI_REMOTE) {
      enterDiscoveryMode("telemetry failed");
      updateServerStatus(false, "WS DOWN");
    }
    refreshDisplay(true);
    if (debugVerbose) Serial.println("[telemetry] failed");
  }
}

void sendSwipe(const char* dir) {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!ensureServerTarget()) return;
  if (debugVerbose) {
    Serial.print("[swipe] sending dir=");
    Serial.println(dir);
  }
  String payload = "{";
  payload += jsonStringField("type", "swipe");
  payload += jsonStringField("device", DEVICE_NAME);
  payload += jsonStringField("dir", dir, true);
  payload += "}";
  const int code = postJson("/api/swipe", payload);
  if (code >= 200 && code < 300) {
    updateServerStatus(true, "SWIPE OK");
  } else {
    updateServerStatus(false, "SWIPE ERR");
  }
}

void processPendingDiscoveryScan() {
  if (!discoveryScanPending) return;
  if (WiFi.status() != WL_CONNECTED) {
    discoveryScanPending = false;
    discoveryScanInProgress = false;
    clearDiscoveryServices();
    discoveryDirty = true;
    refreshDisplay(true);
    return;
  }

  discoveryScanPending = false;
  discoveryScanInProgress = true;
  discoveryDirty = true;
  refreshDisplay(true);

  const unsigned long start = millis();
  const int count = scanBonjourServices(true);
  if (debugVerbose && !DISCOVERY_TOUCH_DIAG_ONLY) {
    Serial.print("[mdns] rescan done count=");
    Serial.print(count);
    Serial.print(" elapsed_ms=");
    Serial.println(millis() - start);
  }

  discoveryScanInProgress = false;
  discoveryDirty = true;
  refreshDisplay(true);
}

void handleSerialCommands() {
  while (Serial.available() > 0) {
    const char c = (char)Serial.read();
    if (c == 'n' || c == 'N') {
      sendSwipe("next");
    } else if (c == 'p' || c == 'P') {
      sendSwipe("prev");
    } else if (c == 't' || c == 'T') {
      sendTelemetry();
    } else if (c == 'h' || c == 'H') {
      announceIfReady();
    } else if (c == 'd' || c == 'D') {
      debugVerbose = !debugVerbose;
      Serial.print("[debug] verbose=");
      Serial.println(debugVerbose ? "on" : "off");
    }
  }
}

void handleOptionalButton() {
  if (OPTIONAL_NEXT_BUTTON_PIN < 0) return;
  const unsigned long now = millis();
  if (now - lastButtonSampleAt < 40) return;
  lastButtonSampleAt = now;

  const bool pressed = digitalRead(OPTIONAL_NEXT_BUTTON_PIN) == LOW;
  if (pressed && !lastButtonPressed) {
    sendSwipe("next");
  }
  lastButtonPressed = pressed;
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println();
  Serial.println("ESP32-C3 generic display demo boot");
  Serial.print("[boot] fw=");
  Serial.println(FW_VERSION);

  parseServerUrl();
  if (!ensureServerTarget()) {
    Serial.println("Will try mDNS after Wi-Fi comes up");
  }
  initDisplay();
  initTouch();
  pinMode(OPTIONAL_NEXT_BUTTON_PIN, INPUT_PULLUP);
  connectWifi();
}

void refreshDisplay(bool force) {
  const unsigned long now = millis();
  if (!force && now - lastDisplayRefreshAt < DISPLAY_REFRESH_MS) return;
  lastDisplayRefreshAt = now;

  if (displayUiMode == DISPLAY_UI_DISCOVERY || displayUiMode == DISPLAY_UI_CONNECTING) {
    if (!force && !discoveryDirty) return;
    discoveryDirty = false;
    drawDiscoveryScreen();
    return;
  }

  if (WiFi.status() == WL_CONNECTED) {
    if (remoteDisplayTitle.length() > 0 || remoteDisplaySubtitle.length() > 0 || remoteDisplayLine1.length() > 0) {
      if (debugVerbose) {
        Serial.print("[display-screen] page=");
        Serial.println(remoteDisplayTitle);
      }
      showStatusScreen(
        remoteDisplayTitle.c_str(),
        remoteDisplaySubtitle.c_str(),
        remoteDisplayLine1.c_str(),
        remoteDisplayLine2.c_str(),
        remoteDisplayLine3.c_str()
      );
      return;
    }

    char ipLine[32];
    snprintf(ipLine, sizeof(ipLine), "IP %s", deviceIp.c_str());
    char fwLine[32];
    snprintf(fwLine, sizeof(fwLine), "FW %s", FW_VERSION);
    if (debugVerbose) {
      Serial.print("[display-screen] status=");
      Serial.print(serverStatusDetail);
      Serial.print(" fw=");
      Serial.println(FW_VERSION);
    }
    showStatusScreen("CONNECTED", ipLine, serverStatusDetail.c_str(), fwLine, "");
  } else {
    displayUiMode = DISPLAY_UI_WAITING;
    showStatusScreen("WAITING", "Wi-Fi not connected", "module booted", "", "setup mode");
  }
}

void loop() {
  if (displayUiMode == DISPLAY_UI_DISCOVERY) {
    if (discoveryFlashActive) {
      if (millis() >= discoveryFlashUntil) {
        discoveryFlashActive = false;
        gfx->fillScreen(RGB565_BLACK);
      }
      delay(5);
      return;
    }

    handleDiscoveryTouch();
    if (discoveryFlashActive) {
      delay(5);
      return;
    }

    processPendingDiscoveryScan();
    if (discoveryTapRestorePending) {
      if (millis() >= discoveryTapRestoreAt) {
        discoveryTapRestorePending = false;
        discoveryDirty = true;
        refreshDisplay(true);
      }
    } else {
      refreshDisplay();
    }
    delay(5);
    return;
  }

  handleSerialCommands();
  logWifiStateIfChanged();
  if (displayUiMode == DISPLAY_UI_DISCOVERY || displayUiMode == DISPLAY_UI_CONNECTING) {
    handleDiscoveryTouch();
  } else {
    handleTouch();
  }

  processPendingDiscoveryScan();
  handleOptionalButton();
  const bool wifiConnectedAtLoop = WiFi.status() == WL_CONNECTED;
  const bool discoveryIdle = displayUiMode == DISPLAY_UI_DISCOVERY && !discoveryScanPending && !discoveryScanInProgress;
  if (!(discoveryIdle && wifiConnectedAtLoop)) {
    connectWifi();
  }

  if (WiFi.status() == WL_CONNECTED) {
    wifiConnectInFlight = false;
    if (deviceIp.length() == 0) {
      deviceIp = WiFi.localIP().toString();
    }
    if (displayUiMode == DISPLAY_UI_WAITING && serverHost[0] == '\0') {
      enterDiscoveryMode("wifi connected");
      refreshDisplay(true);
      updateServerStatus(false, "WS DOWN");
    }
    if (displayUiMode == DISPLAY_UI_DISCOVERY) {
      if (discoveryServiceCount == 0) {
        updateServerStatus(false, "WS DOWN");
      }
    } else if (displayUiMode == DISPLAY_UI_CONNECTING) {
      const bool haveTarget = ensureServerTarget();
      if (!haveTarget) {
        enterDiscoveryMode("no server target");
        updateServerStatus(false, "WS DOWN");
      } else {
        processDisplayEvents();
      }
    } else {
      const bool haveTarget = ensureServerTarget();
      if (!haveTarget) {
        enterDiscoveryMode("no server target");
        updateServerStatus(false, "WS DOWN");
      } else {
        processDisplayEvents();
        if (!helloSent) {
          announceIfReady();
        }
        if (displayUiMode == DISPLAY_UI_REMOTE && millis() - lastTelemetryAt >= TELEMETRY_PERIOD_MS) {
          lastTelemetryAt = millis();
          sendTelemetry();
        }
      }
    }
  } else {
    if (wifiWasConnected && wifiLostSince > 0 && millis() - wifiLostSince < WIFI_LOST_GRACE_MS) {
      updateServerStatus(false, "WIFI WAIT");
    } else {
      deviceIp = "";
      helloSent = false;
      displayUiMode = DISPLAY_UI_WAITING;
      updateServerStatus(false, "WIFI ERR");
      clearRemoteDisplay();
    }
  }

  refreshDisplay();

  delay(10);
}
