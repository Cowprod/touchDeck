# ESP32-C3 test module

Petit dossier dédié au test matériel du module ESP32-C3 avant toute intégration au synthé.

## Ce que ce test vérifie

- alimentation USB
- connexion série
- téléversement du firmware
- LED intégrée si le module en a une

## Fichier principal

- `esp32c3-test.ino`

## Utilisation

1. Ouvre le projet dans Arduino IDE ou PlatformIO.
2. Sélectionne une carte de type `ESP32C3 Dev Module`.
3. Branche le module.
4. Téléverse le sketch.
5. Ouvre le moniteur série à `115200`.

## Résultat attendu

- le moniteur série affiche un message de boot
- la LED intégrée clignote toutes les 500 ms si le GPIO est correct

## Remarque

Quand le module répond correctement, on pourra ajouter ici un second firmware ou une version plus évoluée pour servir d’interface de contrôle du synthé.
