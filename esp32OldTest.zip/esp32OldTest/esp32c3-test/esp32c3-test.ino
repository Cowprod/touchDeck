// Minimal ESP32-C3 hardware test.
// Goal: confirm USB power, serial upload, and a possible onboard LED.

#ifndef LED_BUILTIN
#define LED_BUILTIN 8
#endif

static const int kLedPin = LED_BUILTIN;
static const unsigned long kBlinkPeriodMs = 500;

unsigned long lastBlinkMs = 0;
bool ledState = false;

void setup() {
  pinMode(kLedPin, OUTPUT);
  digitalWrite(kLedPin, LOW);

  Serial.begin(115200);
  delay(1200);
  Serial.println("ESP32-C3 test boot");
  Serial.print("LED pin: ");
  Serial.println(kLedPin);
}

void loop() {
  const unsigned long now = millis();
  if (now - lastBlinkMs >= kBlinkPeriodMs) {
    lastBlinkMs = now;
    ledState = !ledState;
    digitalWrite(kLedPin, ledState ? HIGH : LOW);
    Serial.println(ledState ? "LED ON" : "LED OFF");
  }
}
